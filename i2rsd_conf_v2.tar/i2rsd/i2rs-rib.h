/*
 * Routing Information Base header
 * Copyright (C) 2016 Susan Hares  
 *
 * This file is part of GNU Zebra I2RS  
 *
 */

#ifndef _I2RS_RIB_H
#define _I2RS_RIB_H

#define HAVE_I2RS_RIB	1

#ifndef HAVE_NETINET_IN 
#define HAVE_NETINET_IN 1
#include "/usr/include/netinet/in.h"
#endif

#ifndef HAVE_NETINT6_IP6_H
#define HAVE_NETINET_IP6_H 1  
#include "/usr/include/netinet/ip6.h"
#endif

/* augments rib.h - included after i2RS  */
/* I2RS external size maximums */

/***  interfaces and tunnels ****/
#define I2RS_IF_NAME_MAX   50
#define I2RS_IF_TABLE_MAX  100
#define I2RS_INTERFACE_NAME_SZ 30 

/**** tunnels ********/
/* interface tunnel table maximums */
#define I2RS_TUN_ENCAP_MAX 50  
#define I2RS_TUN_DECAP_MAX 50

/* Methods */
#define I2RS_ENCAP_MAX  100
#define I2RS_DECAP_MAX  100
 
/* nexthops  */

#define MAX_NH_RT_SHARE  50  
#define MAX_HTC_NH       60 
#define I2RS_MAX_NH_LMEMBERS 50
#define I2RS_RT_NH_MAX      50 
#define I2RS_RT_CHANGE_MAX  10  

/* RIB maximums */
#define I2RS_RIB_RT_MAX    5000
#define I2RS_RIB_MAX_NAME  30    
#define I2RS_RIB_SID_HISTORY 15 
#define I2RS_RIB_NH_MAX    10000
#define I2RS_RT_MAX  	   21000

#define I2RS_OK  1
#define I2RS_ERR 2




/*********** nexthop base definitions  ******/

/* next hop features */
#define IF_nexthop_tunnel	1		
#define IF_nexthop_chain        2 
#define IF_nexthop_protection   3
#define IF_nexthop_replicates   4
#define IF_nexthop_lb           5
#define IF_ipv4_tunnel	   	6
#define IF_ipv6_tunnel 	   	7
#define IF_mpls_tunnel 	   	8
#define IF_vxlan_tunnel         9  
#define IF_gre_tunnel	   	10
#define IF_vendor_attributes	11

/* nexthop type (not identityref */

#define NHT_NONE 	  	0
#define NHT_NEXTHOP_BASE  	1
#define NHT_NEXTHOP_CHAIN 	2
#define NHT_NEXTHOP_REPLICATES	3
#define NHT_NEXTHOP_PROTECTION 	4
#define NHT_NEXTHOP_LB	5
 

/* i2rs mpls label actions */

#define I_label_push  1
#define I_label_pop   2
#define I_label_swap  3

/* tunnel decapsulation */

#define I_tunnel_decap 0 
#define I_ipv4_decap   1 
#define I_ipv6_decap   2

#define I_ttl_noact 1
#define I_ttl_copy_to_inner 2
#define I_ttl_decrease_copy_inner 3
#define I_ttl_decrease_copy_next  4

#define I_hop_limit_noact 1
#define I_hop_limit_copy_inner 2

#define I_S_NH_DISCARD	    0  
#define I_S_NH_DISCARD_ERR  1	 
#define I_S_NH_RECEIVE      2 
#define I_S_NH_COS_VALUE    3 
#DEFINE I_S_NH_MAX          3

#define I2RS_RT_MATCH_MAX 3
#define I_match_ip_src	0 
#define I_match_ip_dest	1 
#define I_match_ip_src_dest 2 

#define I_match_mpls_subtype 0 
#define I_match_mac_subtype  0
#define I_match_if_subtype  0  

#define I_match_rib_max       	4 
#define I_match_rib_notype    	0
#define I_match_rib_ipv4      	1 
#define I_match_rib_ipv6      	2
#define I_match_rib_mpls      	3
#define I_match_rib_IEEE_MAC	4

/* route types */

#define I_rt_notype 0 
#define I_rt_ipv4   1 
#define I_rt_ipv6   2
#define I_rt_mpls   3
#define I_rt_ieee_mac  4
#define I_rt_interface 5
#define I_rt_type_max  5


#define I_tunnel_ipv4  1
#define I_tunnel_ipv6  2
#define I_tunnel_mpls  3
#define I_tunnel_gre   4
#define I_tunnel_vxlan 5
#define I_tunnel_nvgre 6

#define	I_rt_state_active  0
#define I_rt_state_inactive 1
#define I_rt_nh_state_resolved 0
#define I_rt_nh_state_unresolved 1
#define I_rt_installed 0 
#define I_rt_uninstalled 1

#define I_rtc_lower_rt_pref 0 
#define I_rtc_higher_rt_pref 1 
#define I_rtc_nh_resolved 2

#define I_rt_subtype_v4_dst
#define I_rt_subtype_v4_src
#define I_rt_subtype_v4_dst_src

#define I_rt_subtype_v6_dst
#define I_rt_subtype_v6_src
#define I_rt_subtype_v6_dst_src


#define I2RS_v6_DST_ONLY 0
#define I2RS_v6_SRC_ONLY 1
#define I2RS_v6_DST_SRC  2


#define I_NVGRE_V4 1
#define I_NVGRE_V6 2

  struct nvgre_hdr {
     uint8_t type;
     union {
     	struct iphdr  ipv4; 
     	struct ip6_hdr ipv6;
    	} ip_header; 
     uint32_t vsid; 	/* virtual_subnet_id */
     uint16_t flow_id;  
    };

#define I_VXLAN_V4  1
#define I_VXLAN_V6  2	

  struct vxlan_hdr {
     uint8_t type;
  union {
     struct iphdr ipv4; 
#ifdef HAVE_IPV6
     struct ip6_hdr ipv6;
#endif
    } ip_header; 
     uint32_t vlan_id;	/* vxlan_identifier */
   };

 
/* MPLS type */
    I_MPLS_LABEL_PUSH 0
    I_MPLS_LABEL_POP  1   
    I_MPLS_LABEL_SWAP 2
 
  /* push - label, s-bit, tc, ttl */ 

   struct i_mpls_label_push {
     uint32_t label;
     uint8_t  sbit; /* boolean */
     uint8_t  tc;    
     uint8_t  ttl;
   }

#define I_MPLS_ENCAP_PUSH 	1
#define I_MPLS_ENCAP_SWAP	2 

#define MPLS_SWAP_TTL_NO_ACT		1 		
#define MPLS_SWAP_TTL_COPY_INNER	2
#define MPLS_SWAP_TTL_DEC_OUTER 	3
 
   struct i_mpls_label_swap {
     uint32_t in_label; 
     uint32_t out_label;
     uint8_t  ttl_act;
  };

    struct mpls_encap {
     uint8_t  type;
     uint32_t label-oper-id;
	union {
	struct i_mpls_label_push push; 
	struct i_mpls_label_swap swap; 
	} mpls_en;	  
     };

   #define I_GRE_V4 1
   #define I_GRE_V6 2 

   struct gre_hdr {
     uint8_t type;
     union {
     	struct iphdr ipv4; 
     	struct ip6_hdr ipv6;
    	} ip_header; 
    uint16_t protocol; 
    uint64_t key;
   };


   struct i2rs_tunnel_encap {
      uint16_t te_id;
      int      refcnt;
      uint16_t te_type;
 	union {
     struct iphdr ipv4; 
#ifdef HAVE_IPV6
     struct ip6_hdr ipv6;
#endif
     struct mpls_encap mpls; 
     struct nvgre_hdr nvgre;  
     struct vxlan_hdr vxlan;
     struct gre_hdr  gre; 
      } te; 
    };


#define I_decap_v4  0 
#define I_decap_v6  1
#define I_decap_mpls 2
#define I_decap_mpls_pop 2
#define I_decap_ttl_same  0
#define I_decap_ttl_dec   1


  struct i2rs_tunnel_decap {
   uint8_t   decap_action; /* decap action */
   uint8_t   ttl_action;   /* ipv4 decap */
   uint16_t  hop_limit;    /* ipv6 decap */
  };


#define I2RS_IF_TABLE_CREATE_ERROR 1 
   
 struct i2rs_if {
     int 	if_used;
     int	ifs_tab_idx;	 
     uint32_t   if_id;
     uint32_t	if_ns; 
     ifindex_t	if_idx;
     uint16_t   if_name_cnt;        
     char	if_name[I2RS_INTERFACE_NAME_SZ]; 
 };

 
/* encapsulations methods per interface */
 
  struct i2rs_tun_encap_iftab {
     int	      ifcnt;
     struct i2rs_if  *iff; 		
     int              encap_idx[I2RS_TUN_ENCAP_TABLE_SZ];
  };
   
  typedef struct i2rs_tun_encap_table i2rs_tun_encap_tab_t;   

/* decapsulations methods per interface */

  struct i2rs_tun_decap_iftab {
     int        ifcnt;  	
     i2rs_if_t  *iif;   
     int 	decap_idx[I2RS_TUN_DECAP_TABLE_MAX];
  };
 

  struct i2rs_if_table {
     strucct i2rs_instance        *p_ii
     uint32_t        	           if_cnt; 
     i2rs_if_t  	           ifs[I2RS_IF_TABLE_MAX]; 
     struct i2rs_tun_encap_iftab  *te[I2RS_TUN_ENCAP_MAX];
     struct i2rs_tun_decap_iftab  *de[I2RS_TUN_DECAP_MAX];
     int 		           te_cnt;
     int		           de_cnt;  
     struct i2rs_tunnel_encap_t   *encap[I2RS_ENCAP_MAX]
     struct i2rs_tunnel_decap_t   *decap[I2RS_DECAP_MAX]
     int		           encap_cnt;
     int 		           decap_cnt;
  }
 
   typedef struct i2rs_if_table i2rs_if_table_t ;	
 
  struct ifegress_v4 {
    int     	       eif_idx;  /*i2rs */ 	  	   	
    struct   in_addr   v4_addr;   /*zebra*/     
   }
  struct ifegress_v6 {
    int     	       eif_idx;  /*i2rs */ 	  	   	
    struct   in6_addr   v4_addr;   /*zebra*/     
   }

  struct ifegress_mac {
    int    eif_idx;	  /*i2rs */ 
    uint32_t  mac;        /* ieee mac address */
   };
 
  struct logical_tunnel {
    int     elf_idx;
    uint8_t ltun_type;
    char    ltun_name[I2RS_IF_NAME_MAX];
   };

  struct inh_rib {  
    char  	rib_name[I2RS_RIB_MAX_NAME]; /* name sent */
    i2rs_rib_t  *p_rib;  	  
  };

#define I_NHB_SUBTYPE_SPECIAL	0
#define I_NHB_SUBTYPE_EGRESSIF  1
#define I_NHB_SUBTYPE_IPV4 	2
#define I_NHB_SUBTYPE_IPV6	3
#define I_NHB_SUBTYPE_EIF_IPV4  4	
#define I_NHB_SUBTYPE_EIF_IPV6	5
#define I_NHB_SUBTYPE_EIF_MAC	6
#define I_NHB_SUBTYPE_TUN_ENCAP 7
#define I_NHB_SUBTYPE_TUN_DECAP 8
#define I_NHB_SUBTYPE_LOG_TUN   9 
#define I_NHB_SUBTYPE_RIB	10	
#define I_NHB_SUBTYPE_NH_ID	11

 
  struct i2rs_nh_base {
     union {
    	uint8_t			special_nh; 
        int		 	eif_idx;   
	in_addr 		ipv4;
	in6_addr 		ipv6;
	struct ifegress_v4	ife_ipv4;
	struct ifegress_v6 	ife_ipv6;
	struct ifegress_mac 	ife_mac;
    	struct itunnel_encap 	t_encap; /* encap tunnel */
    	struct itunnel_decap 	t_decap; /* decap tunnel */
	struct inh_rib		nh_rib;	/* fwd via rib  */
	uint32_t	        nh_id;	 
	} nhb;
   }; 


#define NHC_SAME_RT_NS		/* same RT NH share */
#define NHC_SAME_RT_SH		/* same RT NH no-share */ 
#define NHC_DIFF_RT_NS		/* diff RT share  
#define NHC_DIFF_RT_SH		/* diff RT no-share */

   struct i2rs_nh_list {
  	uint32_t nh_member_id[I2RS_MAX_NH_LMEMBERS];  
    };

  struct i2rs_nh_list_p {
     uint32_t nh_member_id[I2RS_MAX_NH_LMEMBERS];  
     uint8_t nh_preference[I2RS_MAX_NH_LMEMBERS];   
    };

  struct i2rs_nh_list_w {
    uint32_t nh_member_id[I2RS_MAX_NH_LMEMBERS];  
    uint8_t nh_weight[I2RS_MAX_NH_LMEMBERS];   
  };


/* forward definition */  
  struct i2rs_nh_rtc 

/* I2RS_MAX_HTC_NH - maximum nexthop changes   
 *              must be more than I2RS_MAX_NH_RT_SHARE 
 * I2RS_MAX_NH_RT_SHARE  - maximum routes sharing nh
 */


struct i2rs_nexthop {
 	uint32_t  nexthop_id;
 	uint8_t   nhsharingflag; /* should be boolean */
 	uint16_t  nexthop_type;
	uint16_t  nexthop_subtype;
 	union {
    	  struct  i2rs_nh_base   nh_base; 
    	  struct  i2rs_nh_list   nh_chain;
    	  struct  i2rs_nh_list   nh_replicates;
    	  struct  i2rs_nh_list_p nh_protection;
    	  struct  i2rs_nh_list_w nh_load_balance; 
    	} nh;

	/* additional calculated links */	
	struct i2rs_rib    *rib;	/* rib id */
        int 	    	    rib_sid;	/* rib sid */
	int 		    nh_sid;	/* nh sid */
	struct  i2rs_route *rt[MAX_SHARE_RT];
	uint64_t	    rt_idx[I2RS_MAX_NH_RT_SHARE];
	int 		    nh_s_rt_nt;
     	struct nhc	    nh_htc[I2RS_MAX_HTC_NH];
	int 		    nh_htc_cnt; 
 
   };   

    typedef struct i2rs_nexthop i2rs_nexthop_t ;


#define I2RS_HTC_ADD
#define I2RS_HTC_DELETE
#define I2RS_HTC_CHANGE

/* SID (rib, rt, nh) - at time of change 
 * route id, ptr to
 * change flags (add/change, delete) 
 * share flag  [nh_ce->nhsharingflag]     
 */
   struct i2rs_sid {  
       	uint64_t	     rib_sid; 
	uint64_t	     rt_sid; 
	uint64_t	     nh_sid;
	uint64_t	     rtc_sid;
	uint64_t	     nhc_sid; 		 
   };

typedef struct i2rs_sid  i2rs_sid_t 

   struct i2rs_nhc {
	int 		     nhc_sid;
	uint64_t	     rt_idx;
	struct i2rs_route   *p_rt;		
	int		     chg_flags;	
	struct i2rs_nexthop *nh_ce;
   }

   typedef struct i2rs_nhc i2rs_nhc_t  

   struct i2rs_AFI_rt_attr {
  	int16_t afi;  /* afi */ 
  	uint8_t safi; /* safi */
   };  

/* route attributes */

   struct i2rs_rt_attr {
 	uint32_t route_preference; 
 	uint8_t  local_only;   /* boolean */
 	struct   i2rs_AFI_rt_attr attr[I_rt_type_max];   
   }; 

/* route status structure */
/* operational state (Io_rt_x) */

  struct route_status {
	uint8_t route_state;           /* (in)active */
   	uint8_t route_installed_state; /* (un)installed */ 
   	uint16_t  route_reason;        /* rt-change reason */
   	struct  i2rs_rt_attr *route_attributes;
   	struct  i2rs_rt_attr *vendor_route_attributes;  
   };

  struct pfx_v6 {
    uint16_t	afi; 
    uint32_t	len;  
    struct	in6_addr pfx6;   
  };

  struct pfx_v4 {
    uint16_t	afi; 
    uint32_t  	len;
    in_addr_t   pfx4;  
  };


  struct pfx_sdst_ipv4 {
 	struct pfx_v4	dest_ipv4;
	struct pfx_v4	src_ipv4;
   }; 

   struct pfx_sdst_ipv6 {
   	struct pfx_v6	dest_ipv6;
   	struct pfx_v6	src_ipv6;
   }; 

#define I2RS_INTERFACE_NAMSIZ 80  



  struct i2rs_pfx_match {
    union {
 	struct pfx_v4		dest_ipv4_addr;
	struct pfx_v4		src_ipv4_addr;
	struct pfx_sdst_ipv4	sdst_ipv4_addr;
	struct pfx_v6		dest_ipv6_addr;
	struct pfx_v6		src_ipv6_addr;	
	struct pfx_sdst_ipv6	sdst_ipv6_addr;
	struct i2rs_if		if_pfx; 
       	uint32_t		mpls_label;
       	uint32_t		mac;
     } m; 
   };

/* rt_type =  i2rsI_rt_xxx */

  struct i2rs_route_prefix {
	uint64_t   rt_index;  
 	uint16_t   rt_type;  
        uint16_t   rt_subtype; 
	struct i2rs_pfx_match pfx_match; 
   }; 

 struct i2rs_rt_status {
	uint16_t    route-state;
	uint16_t    route-installed-state;
        uint16_t    route-reason;   
 }

 
  /* nexthop 
   */

   I2RS_RTC_NONE   0
   I2RS_RTC_PREFIX 1
   I2RS_RTC_NHLIST 2 
   I2RS_RTC_ATTRS   4 

  struct i2rs_rtc {
	struct i2rs_sid		  sid;
	uint64_t		  nh_list_id[I2RS_MAX_CHG_NH];
	uint8_t	 	 	  chg_flags;
	struct i2rs_route_prefix *tmp_rt;
	struct i2rs_nexthop 	 *tmp_nhl[I2RS_MAX_CHG_NH];
  	struct i2rs_rt_attr	 *tmp_rt_attr;
	struct i2rs_rt_attr	 *tmp_v_attr;
  };

  typedef struct i2rs_rtc i2rs_rtc_t;  	

 /* route */

   struct i2rs_route {
 	struct i2rs_route_prefix  rt_prefix;
        uint32_t		nh_cnt;
  	struct i2rs_nexthop     *rt_nh[I2RS_RT_NH_MAX];
	struct i2rs_rt_status	rt_status; 
  	struct i2rs_rt_attr	rt_attr;
  	struct i2rs_rt_attr	rt_vattr; 
	uint64_t 		rt_sid;
	uint64_t 		rtc_cnt;
	struct i2rs_rtc		*rtc[I2RS_RT_CHANGE_MAX]; 
   };

   #define rt_idx  i2rs_route_prefix.rt_index


   /* i2rs RIB   
    *   ip_rpf_check is boolean
    */

   struct i2rs_rib {
  	char 		*name;   
  	uint16_t	afi; 
  	uint8_t 	safi;
  	uint8_t		ip_rpf_check;  
	uint64_t	sid[I2RS_RIB_SID_HISTORY];
	uint64_t        c_sid; /* current sid */
	uint32_t	nhs_cnt; /* nexthop share cnt */
	uint32_t	nhns_cnt; /* nexthop no share cnt */
	int		rtc_cnt; /* turn into queue */
	int		nhc_cnt; /* turn into queue */ 
	uint32_t 	rt_cnt;
  	struct i2rs_route   *rtl[I2RS_RIB_RT_MAX]; /*route list */
	struct i2rs_nexthop *nh_s[I2RS_RIB_NH_MAX]; /*share nh list */
	struct i2rs_nexthop *nh_ns[I2RS_RIB_NH_MAX; /*no-share nh list */  
	vrf_id_t	vrf_id;
	zebra_vrf_t 	*p_zvrf;
	int  		rt_zproc_status; /* zebra process  */ 
        int		rt_p_status;     /*pending status */
    };

  typedef struct i2rs_rib i2rs_rib_t;

/* i2rs Routing instance name.  */

#define I2RS_MAX_INSTANCE_NAME 80 
#define I2RS_MAX_RIB_NAME 80 
#define I2RS_MAX_IF_NAME 80
#define I2RS_MAX_IF 100

  struct i2rs_instance { 
  	char 		*name;   
   	in_addr_t 	router_id; 
   	uint8_t 	lookup_limit;
        int		if_cnt;		
   	char 		*if_name[I2RS_MAX_IF];
        vrf_id_t	vrf_id;
        zebra_vrf	*zvrf; 
  };

typedef struct i2rs_instance_info i2rs_instance_t ;
 

#endif /*_I2RS_RIB_H */
