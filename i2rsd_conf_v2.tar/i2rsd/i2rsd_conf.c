/*********************************************************************
 * ConfD Subscriber intro example
 * Implements a DHCP server adapter
 *
 * (C) 2005-2007 Tail-f Systems
 * Permission to use this code as a starting point hereby granted
 *
 * See the README file for more information
 ********************************************************************/
#include <sys/poll.h>
#include <confd_lib.h>
#include <confd_cdb.h>
#include "memtypes.h"
#include "rt.h"
#include "linuxcfg_api.h"

/* include definitions for route table */
/* include generated file */
#include "ietf-i2rs-rib.h"
#include "ietf-interfaces.h"

 /********************************************************************/

 /**********external route routines **************/

  /* find route in route list */

  extern int 
  find_rt (i2rs_rib_t *p_rib, uint64_t rt_id) 
  {
   int i, max;  
  
	max =  p_rib->rt_cnt; 
    	for (i = 0; i < max; i++) {
	  if (p_rib->rtl[i]->rt_prefix.rt_index == rt_id) {
		return(i);   
	  }
	}
	return (-1);
  }     

 /* create ann external route */
  extern i2rs_route_t * 
  create_rt(i2rs_rib_t *p_rib, uint64_t rt_index)
  {
     
    i2rs_route_t *p_rt;

    p_rt = (i2rs_route_t *) XMALLOC(MTYPE_I2RS_ROUTE,sizeof(i2rs_route_t));
    p_rt->rt_prefix.rt_index = rt_index; 
    p_rt->rt_sid = p_rib->c_sid;

   /* clear change counters */ 
    p_rt->rtc_cnt = 0; 
    p_rt->rt_htc_cnt = 0;  

   /* link to route changes */
    p_rt->rtc[0] = (i2rs_rtc_t *) NULL;
    return (p_rt);
  }

 
  extern i2rs_rtc_t * 
  i2rs_create_rtc (i2rs_rib_t *p_rib, i2rs_route_t *p_rt)
  {
    i2rs_rtc_t *p_rtc;


   /* allocate */ 
    p_rtc = (i2rs_rtc_t *) XMALLOC(MTYPE_I2RS_RTC,sizeof(i2rs_rtc_t));

   /* save sid information frmo route */

    p_rtc->sid.rib_sid =  p_rib->c_sid;
    p_rtc->sid.rt_sid =   p_rt->rt_sid;
    p_rtc->sid.rtc_sid =  p_rt->rt_sid;
    p_rtc->sid.nh_sid = 0;
    p_rtc->sid.nhc_sid = 0;

/* clear change flags route 
   link this rtc to route 
   - now it is ready to set up wtih information.
  */

    p_rtc->chg_flags = 0; 
    p_rt->rtc[p_rt->rtc_cnt] = p_rtc; 
    p_rt->rtc_cnt++; 
    return (p_rtc);
  }
  
  /*******nexthop routines *********************************/

  static i2rs_nexthop_t * 
  i2rs_create_nh(uint32_t nh_idx) 
  { 
    i2rs_nexthop_t *p_nh;
    
    p_nh =(i2rs_nexthop_t *)  XMALLOC(MTYPE_I2RS_NEXTHOP, sizeof(i2rs_nexthop_t));
    p_nh->nexthop_id = nh_idx;
    return (p_nh);
  }

  /* insert nexthop in a route nexthop list  
   */  

  static int   
  i2rs_insert_nh_rt_nhl(i2rs_route_t *p_rt, i2rs_nexthop_t *p_nh)
  {
    /**skh-1  code must be written */
     return (0);    
  }   

 /* insert nexthop in rib lists 
  * shared 
  */

  extern int  
  i2rs_insert_nh_rib (i2rs_rib_t *p_rib, i2rs_route_t *p_rt,i2rs_nexthop_t *p_nh, int shared)   
  {
     /* set link to rib shared NH list */

     if (((shared == 1) && (p_rib->nhs_cnt == I2RS_RIB_NH_MAX)) || 
       ((shared  == 0) && (p_rib->nhns_cnt == I2RS_RIB_NH_MAX)))  { 
	   /* no more rib nh shared space */
	    p_nh->rib = (i2rs_rib_t *) NULL; 
	    return (0);
      }

     /* link to rib structure  
      *  owner (sid)   
      *  rib index (quick table access) 
      */ 

	p_nh->rib = p_rib;
	p_nh->rib_sid = p_rib->c_sid;
	p_nh->rib_idx = p_rib->rib_idx;

     /* clear nexthop change count + first entry */ 
        p_nh->nh_htc_cnt = 0;
	p_nh->nh_htc[0] = (struct i2rs_nhc *) NULL;

    /* store in rib based on nexthop types */
	
    if (shared == 1) {
	/* put in rib shared next hop table */
	p_nh->rib_idx = p_rib->nhs_cnt;
	p_rib->nh_s[p_rib->nhs_cnt] = p_nh;
	p_rib->nhs_cnt++; 
     } else {
	 /* can insert into rib's non-shared NH table */
	p_nh->rib_idx = p_rib->nhns_cnt;
	p_rib->nh_ns[p_rib->nhns_cnt] = p_nh;
	p_rib->nhns_cnt++ ;
       } 

    return (1);
  }

  
  /* find nexthop id in rt 
   * rib (shared nexthop  table)
  *  rib (non-shared nexthop table)  
  */
 
   extern int     
   find_i2rs_nh (i2rs_rib_t *p_rib, i2rs_route_t *p_rt, uint32_t nh_idx, int *rib_nhs_idx, int *rib_nhns_idx) 
   {
   int i,j,k ;
   int max;
   int ret = -1;    
     
      /* search in this route for nh  */ 
      max = p_rt->nh_cnt; 
      for (i = 0; i < max; i++) {
	  if (p_rt->rt_nh[i]->nexthop_id == nh_idx) {
	      ret = i;
	     break; 
	  }
       }

       /* not in the route, search in ribs nexthop links */	

       /* search on the shared rib route */ 
       max = p_rib->nhs_cnt;
       for (j = 1; j < max; j++) {	    	
	  if (p_rib->nh_s[j]->nexthop_id == nh_idx) {
		*rib_nhs_idx = j; 
	  }
       }
       
       max = p_rib->nhns_cnt;
       for (k = 1; k < max; k++) {         
	 if (p_rib->nh_ns[k]->nexthop_id == nh_idx) {
	     *rib_nhns_idx = k; 	
	  }	 
	} 
     	
       return (ret);
	 
  } 

 /************external misc routines *************/
  extern int  
  cpyin6toin6(struct in6_addr *p1, struct in6_addr *p2) 
  {
   int i, ret; 
 
    if (p1 == (struct in6_addr *) NULL || p2 == (struct in6_addr *) NULL) {  
	ret = 0; 
    } else {
       for (i= 0; i< 4; i++) {
	p1->s6_addr32[i] = p2->s6_addr32[i];
        }
       ret = 4;
    }
    return (ret); 
   }  

 /************ external interface table ************/

  extern void 
  create_i2rs_iftable(i2rs_instance_t *p_ii) 
  {
    i2rs_if_table_t *tp;

        tp = (i2rs_if_table_t *) XMALLOC(MTYPE_I2RS_IFTABLE, sizeof(i2rs_if_table_t));

	/* link between instance and if table */
 
        p_ii->if_table =  tp;
	tp->p_ii = p_ii;
        tp->if_cnt = 0;
	tp->te[0] = (struct i2rs_tun_encap_iftab *) NULL;
        tp->de[0] = (struct i2rs_tun_decap_iftab *) NULL;    	
	tp->encap_cnt = 0;
	tp->decap_cnt = 0;
	tp->encap[0] = (struct i2rs_tunnel_encap *) NULL;
        tp->decap[0] = (struct i2rs_tunnel_decap *) NULL;    	
	return; 		
  }
  
 
  /* find the interface by id */
  extern int  
  find_i2rs_if (struct confd_identityref *p_iref, i2rs_instance_t *p_ii)  
  {
   int i;
   int if_cnt;
   i2rs_if_table_t *p_iftab; 

    p_iftab = p_ii->if_table; 
    if_cnt = p_iftab->if_cnt;
    for (i = 0; i < if_cnt ; i ++) {
       if ((p_iref->id == p_iftab->ifs[i].if_id)
          &&& (p_iftab->ifs[i].if_used)) { 
	 return (i);
       }		
    }
    return (-1);  
  }

   /* ifs table  is inline 
    * skh--3: Think about moving to malloc 
    *   
    */ 

   extern void 
   free_i2rs_ifs(i2rs_instance_t *p_ii, int idx) 
   {
     i2rs_if_table_t *p_iftab; 

     p_iftab = p_ii->if_table;
     p_iftab->ifs[idx].if_used = 0;   
     return;
   }


  static void 
  free_i2rs_iftable_entries(i2rs_instance_t *p_ii) 
  {

   int i;
   i2rs_if_table_t *p_iftab; 
   struct i2rs_if_tunnel_encap       *te_method;
   struct i2rs_if_tunnel_decap       *tde_method;
   struct i2rs_if_tun_encap_iftab    *te_iftab;
   struct i2rs_if_tun_decap_iftab    *tde_iftab;

      p_iftab = p_ii->if_table;

     /* interface config + link */
  
      for (i = 0; i < p_iftab->if_cnt; i++)
      {
          p_iftab->ifs[i].if_used = 0;
      }
      p_iftab->if_cnt = 0; 

      /* tunnel encap to interface info table */     

      for (i = 0; i < p_iftab->te_cnt; i++) 
      {
	 te_iftab = p_iftab->te[i];
	 XFREE(MTYPE_I2RS_IF_TUN_ENCAP,te_iftab);  
      }
      p_iftab->te_cnt = 0;

   
     /* tunnel decap to interface info table */     

      for (i = 0; i < p_iftab->de_cnt; i++) 
      {
	tde_iftab = p_iftab->de[i];
	XFREE(MTYPE_I2RS_IF_TUN_DECAP, tde_iftab);  
      }
      p_iftab->de_cnt = 0;
   
     /* configured tunnel encapsulation method */     
 
     for (i = 0; i < p_iftab->encap_cnt; i++) 
     {
	te_method = p_iftab->encap[i];
	XFREE(MTYPE_I2RS_TUN_ENCAP_METHOD, te_method);  
     }
     p_iftab->encap_cnt = 0;

    /* configured tunnel decapsulation method */     
 
     for (i = 0; i < p_iftab->decap_cnt; i++) 
     {
        tde_method = p_iftab->decap[i];
	XFREE(MTYPE_I2RS_TUN_DECAP_METHOD, tde_method);  
        p_iftab->decap_cnt = 0;
     }
  
  }

  /* calling this routine will clean up 
   * interface table
   */   
 
  extern void  
  free_i2rs_iftable (i2rs_instance_t *p_ii) 
  {
    i2rs_if_table_t *p_iftab;
    p_iftab = p_ii->if_table;
    if (p_iftab->if_cnt) { 
	free_i2rs_iftable_entries(p_ii);
    } 
    p_ii->if_table = (i2rs_if_table_t *) NULL;
    XFREE(MTYPE_I2RS_IF_TABLE,p_iftab);

    return; 
  } 

 
 
   /* the interface table currently has a limited 
    * number of interfaces inline 
    */
 
    extern void 
    squish_i2rs_ifs(i2rs_if_table_t  *p_if_tab) 
    {
       /* skh--3  write this routine later 
        * squish the ifs table by walking it 
        * and adjusting the table index 
        */    
      return; 
    } 


  /* insert entry in i2rs if_table 
  * entry is inserted and if updated ok 
  * the the tunnel is linked to routing ifindex 
  * (skh review for zero entry and then remove this comment) 
  */  
 
  extern int  
  insert_i2rs_ifs(struct confd_identityref *p_iref, i2rs_instance_t *p_ii)  
  { 
   int i; 
   i2rs_if_table_t *p_t; 

    if (p_ii->if_table == NULL) {
	/* table starts with zero entry */
	 create_i2rs_iftable(p_ii);
    }

    i = find_i2rs_if(p_iref,p_ii);
 
    if (i <  0) {
    	 if (p_t->if_cnt == I2RS_IF_TABLE_MAX) {
	   /* squish table and rebalance */
	    squish_i2rs_ifs(p_t);

    	   if (p_t->if_cnt == I2RS_IF_TABLE_MAX) {
     		return (-1); 
            }  
	}
	/* store the information regarding interface 
         * in if_table single interface entry (ifs)
         * table add (increate cnt store  
         *
         */
	
    	p_t = p_ii->if_table; 
        p_t->ifs[i].ifs_tab_idx = i; 
        p_t->ifs[i].if_id = p_iref->id;  
        p_t->ifs[i].if_ns = p_iref->ns;  
        p_t->ifs[i].if_idx = (ifindex_t ) 0 ; 
        p_t->ifs[i].if_name_cnt = 0;
        p_t->if_cnt++;
	
      }
    return (i); 
  }    


 /**************end of external interface table routines ********/
 
 /********* external tunnel routines (in iftable)  **************/
     
  extern int  
  create_i2rs_tun_encap_iftab_e (i2rs_if_table_t *p_iftab, int idx, struct i2rs_if *iif)  
  { 
    int i;  
    struct i2rs_tun_encap_iftab *te;
        	
        te = (struct i2rs_tun_encap_iftab *) XMALLOC(MTYPE_I2RS_IF_TUN_ENCAP, sizeof(struct i2rs_tun_encap_iftab));
        te->ifcnt = 1;
	te->iif =  iif;
        i = p_iftab->te_cnt;
        te->encap_idx[i] = idx; 
        p_iftab->te[i] = te;
  	p_iftab->te_cnt = p_iftab->te_cnt + 1;
	return (1);		
  }
  
  extern int  
  create_i2rs_tun_decap_iftab_e (i2rs_if_table_t *p_iftab, int idx, struct i2rs_if *iif)  
  {
    struct i2rs_tun_decap_iftab *tde;
    int i;

        tde = (struct i2rs_tun_decap_iftab *) XMALLOC(MTYPE_I2RS_IF_TUN_DECAP, sizeof(struct i2rs_tun_decap_iftab));
        tde->ifcnt = 1;
	tde->iif = iif;
        i = p_iftab->de_cnt;
        tde->decap_idx[i] = idx; 
        p_iftab->de[i] = tde;   
  	p_iftab->de_cnt = p_iftab->de_cnt +1;
	return(1); 		
  }
   
  /**************end of external tunnel routines *********/

  /****************tunnel routiness *********************/

  static void 
  add_te_v4(struct iphdr *p_ip1, struct iphdr *p_ip2) 
  {
         p_ip1->tos = p_ip2->tos;	
         p_ip1->ttl = p_ip2->ttl;
	 p_ip1->protocol = p_ip2->protocol;  		   	
	 p_ip1->saddr = p_ip2->saddr;
	 p_ip1->daddr = p_ip2->daddr;
	return;
   }

  extern int 
  cmp_ipv4_hdr(struct iphdr *p_ip1, struct iphdr *p_ip2) 
  {
        if ( (p_ip1->tos == p_ip2->tos) &&	
          (p_ip1->ttl == p_ip2->ttl) && 
	 (p_ip1->protocol == p_ip2->protocol) &&  		   	
	 (p_ip1->saddr == p_ip2->saddr) && 
	 (p_ip1->daddr == p_ip2->daddr)) {
	    return (1); 
	}
	return (0); 
  }  	
  
  static int 
  add_te_v6(struct ip6_hdr *p_ip6, struct ip6_hdr *p_ipv6) 
  {
   int ret, ret1, ret2; 

         p_ip6->ip6_flow  = p_ipv6->ip6_flow;	
         p_ip6->ip6_plen  = 0;
	 p_ip6->ip6_nxt   = p_ipv6->ip6_nxt;
         p_ip6->ip6_hlim = p_ipv6->ip6_hlim;
	/* here we need to use the 6 copy */
         ret1 = cpyin6toin6(&p_ip6->ip6_src, &p_ipv6->ip6_src);
         ret2 = cpyin6toin6(&p_ip6->ip6_dst, &p_ipv6->ip6_dst);
         ret = ret1 + ret2;	
	return (ret) ;
   }

 
  /* compare  two ipv6 headers */
 
  extern int 
  cmp_ipv6_hdr(struct ip6_hdr *p_ip6, struct ip6_hdr *p_ip6_2) 
  {
   int i;

         if ((p_ip6->ip6_vfc == p_ip6_2->ip6_vfc) &&	
         (p_ip6->ip6_flow == p_ip6_2->ip6_flow) &&	
	 (p_ip6->ip6_nxt == p_ip6_2->ip6_nxt) &&
         (p_ip6->ip6_hlim == p_ip6_2->ip6_hlim)) {
	    for (i = 0; i < 4; i++) 
            {
	     if (p_ip6->ip6_src.s6_addr32[i] != p_ip6_2->ip6_src.s6_addr32[i]) 
		{
		return (0);
		}
	     if (p_ip6->ip6_dst.s6_addr32[i] != p_ip6_2->ip6_dst.s6_addr32[i]) 
		{
		return (0);
		}
	    }
	/* two addreses match */
	  return (1);
	}	 
	
       /* return of zero is no match */	
      return(0); 
  }

  /* add mpls header */ 
  static void 
  add_mpls_hdr(struct mpls_encap *p_tmpls, struct mpls_encap *p_te)
  { 
    uint8_t type;
    struct i_mpls_label_push *push_to, *push_from; 
    struct i_mpls_label_swap *swap_to, *swap_from;  

        type = p_te->type;
	p_tmpls->type = type;
	switch (type) {
	    case I_MPLS_ENCAP_PUSH:  
		push_to =   &p_tmpls->mpls_en.push;
		push_from = &p_te->mpls_en.push;
		push_to->label = push_from->label;
		push_to->sbit = push_from->sbit;
		push_to->tc = push_from->tc;
		push_to->ttl = push_from->ttl;
		break;

	    case I_MPLS_ENCAP_SWAP: 
		swap_to = &p_tmpls->mpls_en.swap;
		swap_from = &p_te->mpls_en.swap;
	
		swap_to->in_label = swap_from->in_label;	
		swap_to->out_label = swap_from->out_label;	
		swap_to->ttl_act = swap_from->ttl_act;
		break;
	 }
	return;
   }

  /* compare mpls header */
  extern int 
  cmp_mpls_hdr(struct mpls_encap *p_tmpls,struct mpls_encap *p_te)
  { 
    uint8_t type;
    
    
    struct i_mpls_label_push *push1, *push2; 
    struct i_mpls_label_swap *swap1, *swap2; 

	/* if the type and the label operations id match */
        /* compare the push/swap actions */ 
	
	if ((p_tmpls->type == p_te->type) &&
            (p_tmpls->label_oper_id == p_te->label_oper_id)) {

	switch (type) {
	    case I_MPLS_ENCAP_PUSH:  
	        push1 = &p_tmpls->mpls_en.push;
	        push2 = &p_te->mpls_en.push;
		if ((push1->label == push2->label) &&
		    (push1->sbit == push2->sbit) &&
		    (push1->tc == push2->tc) && 
	            (push1->ttl == push2->ttl)) {
		   return (1); 
		}
		break;

	    case I_MPLS_ENCAP_SWAP: 
	        swap1 = &p_tmpls->mpls_en.swap;
	        swap2 = &p_te->mpls_en.swap;
		if ((swap1->in_label == swap2->in_label) &&	
		  (swap1->out_label == swap2->out_label) &&
		  (swap1->ttl_act == swap2->ttl_act)) {
			return (1);
		}
		break;
	 }
	}
	/* not equal */
	return(0); 
   }

  static void 
  add_gre_hdr(struct gre_hdr *p_tab_gre,struct gre_hdr *p_te)
  {
	p_tab_gre->type = p_te->type;
	p_tab_gre->protocol = p_te->protocol;
	p_tab_gre->key = p_te->key;
	switch (p_te->type) {
	    case I_GRE_V4:
		add_gre_v4(&p_tab_gre->ip_header.ipv4, &p_te->ip_header.ipv4);
                break;			 
	    case I_GRE_V6:
		add_gre_v4(&p_tab_gre->ip_header.ipv6, &p_te->ip_header.ipv);
	  	break; 
	 }
	return;	
  } 

/* compare nvgre structure */    
  static int 
  cmp_nvgre_hdr(struct nvgre_hdr *p_h1,struct nvgre_hdr *p_h2)
  { 
	if ((p_tab_gre->type == p_te->type) &&
	    (p_tab_gre->protocol == p_te->protocol) &&
	    (p_tab_gre->key == p_te->key)) {
	     switch (p_te->type) {
	    	  case I_GRE_V4:
		   if (cmp_v4_hdr(&p_tab_gre->ip_header.ipv4, &p_te->ip_header.ipv4)) {
	              return (1);
		   }
                  break;			 
	    	  case I_GRE_V4:
		   if (cmp_v6_hdr(&p_tab_gre->ip_header.ipv6, &p_te->ip_header.ipv6)) {
	              return (1);
		   }
                  break;			 
	     }
	}
	return (0); 	
  }
/* compare gre structure */    
  static int 
  cmp_gre_hdr(struct gre_hdr *p_gre1,struct gre_hdr *p_gre_2)
  { 
	if ((p_gre1->type == p_gre2->type) &&
	    (p_gre1->protocol == p_gre2->protocol) &&
	    (p_gre1->key == p_gre2->key)) {
	     switch (p_gre1->type) {
	    	  case I_GRE_V4:
		   if (cmp_v4_hdr(&p_gre1->ip_header.ipv4, &p_gre2>ip_header.ipv4) {
	              return (1);
		   }
                  break;			 
	    	  case I_GRE_V6:
		   if (cmp_v6_hdr(&p_gre1->ip_header.ipv6, &p_gre2>ip_header.ipv6)) {
	              return (1);
		   }
                  break;			 
	     } /* end switch */
	} /* end if */
	return (0); 	
  }
   
  /* add nvgre header to tunnels */  
  static void 
  add_nvgre_hdr(struct nvgre_hdr *p_nvgre1,struct nvgre_hdr *p_nvgre2)
  {
	p_nvgre1->type = p_nvgre2->type;
	p_nvgre1->vsid= p_nvgre2->vsid;
	p_nvgre2->flow_id = p_nvgre2->flow_id;
	switch (p_nvgre1->type) {
	    case I_GRE_V4:
		add_te_v4(&p_nvgre1->ip_header.ipv4, &p_nvgre2->ip_header.ipv4);
                break;			 
	    case I_GRE_V6:
		add_te_v6(&p_nvgre1->ip_header.ipv6, &p_invgre2->ip_header.ipv5);
	  	break; 
	 }
	return;	
  } 
  
  /* cmp nvgre headers in  tunnel structure  */  
  static int 
  cmp_nvgre_hdr(struct nvgre_hdr *p_nvgre1,struct nvgre_hdr *p_nvgre2)
  {
	if ((p_nvgre1->type == p_te->type) &&
 	    (p_ngre->vsid == p_te->vsid) &&
	    (p_tab_gre->flow_id == p_te->flow_id)) {
	   switch (p_te->type) {
	    case I_NVGRE_V4:
		if (cmp_v4_hdr(&p_tab_nvgre->ip_header.ipv4, &p_te->ip_header.ipv4) {
	          return (1);	
		} 
                break;			 
	    case I_NVGRE_V6:
		cmp_v6_hdr(&p_tab_gre->ip_header.ipv6, &p_te->ip_header.ipv5) {
	          return (1);	
		} 
	  	break; 
	   } /*end switch */
        } /* end if */
	return (0);

  }
        
   
  /* add vxlan header to tunnels */  
  static void 
  add_vxlan_hdr(struct vxlan_hdr *p_tab_vxlan,struct vxlan_hdr *p_te)
  {
	p_tab_vxlan->type = p_te->type;
	p_tab_vxlan->vlan_id = p_te->vlan_id
	switch (p_te->type) {
	    case I_VXLAN_V4:
		add_te_v4(&p_tab_vxlan->ip_header.ipv4, &p_te->ip_header.ipv4);
                break;			 
	    case I_VXLAN_V6:
		add_te_v6(&p_tab_vxlan->ip_header.ipv6, &p_te->ip_header.ipv5);
	  	break; 
	 }
	return;	
  } 

  /* cmp vxlan headers in  tunnel structure  */  
  static int 
  cmp_vxlan_hdr(struct nvgre_hdr *p_tab_nvgre,struct nvgre_hdr *p_te)
  {
	if ((p_tab_vxlan->type == p_te->type) &&
 	    (p_tab_vxlan->vlan_id == p_te->vlan_id) {
	   switch (p_te->type) {
	    case I_VXLAN_V4:
		if (cmp_v4_hdr(&p_tab_nvgre->ip_header.ipv4, &p_te->ip_header.ipv4) {
	          return (1);	
		} 
                break;			 
	    case I_VXLAN_V6:
		cmp_v6_hdr(&p_tab_gre->ip_header.ipv6, &p_te->ip_header.ipv5) {
	          return (1);	
		} 
	  	break; 
	   } /*end switch */
        } /* end if */
	return (0);
  } 
  
  /* add entry to tunnel encapsulation method table */	
  static int  
  add_tencap_te (i2rs_if_table *p_iftab, i2rs_tunnel_encap_t *p_te, int i)
  {
  i2rs_tunnel_encap_t *p_tab_e;
  int idx;
  uint8_t type;

    if (p_iftab->encap_cnt => I2RS_ENCAP_MAX) {
	return (-1);
    }
           
    p_tab_e->te_id = i;
    p_tab_e->te_type = p_te->te_type;
    switch (p_te->te_type) {
       case I_tunnel_ipv4:
	 add_te_v4(&p_tab_e->te.ipv4,&p_te->ipv4)
	break; 
       case I_tunnel_ipv6:
	 add_te_v4(&p_tab_e->te.ipv6,&p_te->ipv6)

       case I_tunnel_mpls:
	 add_mpls_hdr(&p_tab_e->te.mpls,&p_te->mpls)
	 break;
       case I_tunnel_nvgre
	 add_gre_hdr(&p_tab_e->te.nvgre,&p_te->nvgre)
	 break; 
       case I_tunnel_vxlan:
	 add_vxlan_hdr(&p_tab_e->te.vxlan,&p_te->vxlan)
	 break; 

       case I_tunnel_gre:
	 add_gre_hdr(&p_tab_e->te.gre,&p_te->gre)
	 break;
    }
    p_iftab->encap_cnt ++;
    return;   
  }   
  
  /* find the tunnel encapsulation table enctry  by comparison 
   *  (suggestion to ietf-i2rs-rib) -use an  id 
   */
  extern int  
  find_i2rs_tencap_te(struct i2rs_tunnel_encap *p_tee, i2rs_instance_t *p_ii)  
   {

   int i;
   struct i2rs_tunnel_encap *p_tab_te; 
   i2rs_if_table_t *p_ift;

    p_ift = p_ii->if_table;    
 
    for (i = 0; i < p_ift->te_cnt; i ++) {
        p_tab_te = p_ift->encap[i];	
	switch (p_tee->te_type) { 
	 case I_tunnel_ipv4: 
	   if (cmp_ipv4_hdr(&p_tee->te.ipv4,&p_tab_te->te.ipv4)) {
	     return (i);     
 	   }
	   break;  
	 case I_tunnel_ipv6:  
	   if (cmp_ipv6_hdr(&p_tee->te.ipv6,&p_tab_te->te.ipv6)) {
	     return (i);     
 	   }
	   break;  
	 case I_tunnel_mpls: 
	   if (cmp_mpls_hdr(&p_tee->te.mpls,&p_tab_te->te.mpls)) {
	     return (i);     
 	   }
	   break;  
	 case I_tunnel_gre: 
	   if (cmp_gre_hdr(&p_tee->te.gre,&p_tab_te->te.gre)) {
	     return (i);     
	   }
	   break;  
	  case I_tunnel_vxlan: 
	   if (cmp_vxlan_hdr(&p_tee->te.vxlan,&p_tab_te->te.vxlan)) {
	     return (i);     
	   }
	   break;  
	  case I_tunnel_nvgre: 
	   if (cmp_vxlan_hdr(&p_tee->te.nvgre,&p_tab_te->te.nvgre)) {
	     return (i);     
	   }
	   break;  
	}
    }
    return (-1);  
  }
  
  
   /* find the tunnel decapsulation by comparison 
   *  in future ask for it by id 
   */
  static  int  
  find_i2rs_tdecap_te(i2rs_tunnel_decap_t *p_tde, i2rs_instance_t *p_ii)  
  {
    int i,max;
    i2rs_tunnel_decap_t *p_decap;
    i2rs_if_table_t *p_iftab;

    p_iftab = p_ii->zvrf->i2rs_if_tab;
    max = p_iftab->decap_cnt;  
     
      for (i = 0; i < max ; i ++) {
    	if ((p_iftab->decap[i]->decap_action == p_tde->decap_action) &&
           (p_iftab->decap[i]->ttl_action == p_tde->ttl_action) && 
           (p_iftab->decap[i]->hop_lmit == p_tde->hop_limit)) {
            /* found match entry - return index */  
             return (i); 
 	}  
       }
    return (-1);  

  }

  static in 
  squish_te_tab(i2rs_if_table p_iftab) {
      /* skh- write squish code later */
      return (0);
  } 

  /* create i2rs tunnel encap--if_table match entry 
   *  - after load, then link to either I2rs IF or 
   *    system ifindex 
   */    
 
  static int  
  insert_i2rs_tun_encap_iftab_e(i2rs_tun_encap_iftab_t *p_te, i2rs_instance_t *p_ii, i2rs_if_t *iff)  
  { 
    int i, max, idx; 
    i2rs_tun_encap_iftab_t *p_te_tab;
    i2rs_if_table_t *p_if_tab; 

	/* find a place to put it frist  */
        p_iftab = p_ii->zvrf->i2rs_if_tab;
	if (p_iftab->te_cnt > I2RS_TUN_ENCAP_MAX) {
            if (squish_te_tab(p_iftab) == 0)  {
	    /*nothing squished */
		return (-1); 	
            }	 
        }
        return(create_i2rs_tun_encap_iftab_e (p_ift, int idx, i2rs_if_t *iif);  
   }
	
  extern int  
  insert_i2rs_tun_encap_method(i2rs_tunnel_encap_t *p_te, i2rs_instance_t *p_ii)  
  {
     i2rs_if_table *p_iftab;
  	
   	p_iftab = p_ii->zvrf->i2rs_if_tab;_
    	i = find_tencap_te(p_iftab,p_te);
	if (i > -1) { 
	   /* found entry - do not need to make a new one */
	   p_te_tab->encap_tab[i]->refcnt++;
	   return (i);
	}
	else {
    	  if (p_iftab->encap_cnt => I2RS_TUN_ENCAP_TABLE_MAX) {
	     return (-1);
	  } else {  
	    /* room in table, add new entry */
	     add_tencap_te(p_iftab, *p_te);
	  } /*inner else */ 
	}
    return (i); 
  }    	
 
 
   static int  
   get_eif (int rsock,FILE *fp, struct confd_identityref *p_ifref,i2rs_instance_t *p_ii,*p_ifidx,int tag1,int tag2) 
   {
     int ret; 
     int idx;  
	ret  = cdb_get_identityref(rsock, &p_iref, "outgoing-interface");
	if (ret == CONFD_OK) {
	   fprintf (fp,"egress-if %d " [tag=%d] [tag=%d]",tag1, tag2, if-ref.id);
	   /* insert ifs and increment count, 
            *  return new table ifs table in 
             */
	   if (idx == I2RS_IF_TABLE_MAX)  {
   	       printf (fp,"over i2rs ip table max: [tag=%d] [tag=%d]",idx, tag, tag2);
	       ret = CONFD_ERR; 
	    } else {
	       idx = insert_i2rs_ifs(&if-ref, p_ii); 
	       *p_ifidx = idx;    
	    } 
         } else {
	   ret = CONFD_ERR;
	   fprintf (fp,"failure %d nexthop base, egress ip" [tag=%d] [tag=%d]",ret, tag1, tag2);
	 }
      return (ret)
    }

    /* get ipv4-address from data base */

    static int  
    get_nh_ipv4(int rsock, FILE *fp, in_addr *p_v4, int tag, int tag2) 
    { 
	int ret;
        string *p_str; 
        char buf[30];  
 
 	ret  = cdb_get_ipv4(rsock, p_v4, "ipv4-address");
        return(check_nh_ipv4 (fp, p_v4, tag, tag2, ret)); 
    }
    
   /* get src-ipv4-address from data base */

    static int  
    get_nh_src_ipv4(int rsock, FILE *fp, in_addr *p_v4, int tag, int tag2) 
    { 
	int ret;
        string *p_str; 
        char buf[30];  
 
 	ret  = cdb_get_ipv4(rsock, p_v4, "src-ipv4-address");
        return(check_nh_ipv4 (fp, p_v4, tag, tag2, ret)); 
    }
   
/* get src-ipv4-address from data base */

    static int  
    get_nh_dest_ipv4(int rsock, FILE *fp, in_addr *p_v4, int tag, int tag2) 
    { 
      int ret;
      string *p_str; 
      char buf[30];  
 
 	ret  = cdb_get_ipv4(rsock, p_v4, "dest-ipv4-address");
        return(check_nh_ipv4 (fp, p_v4, tag, tag2, ret)); 
    }
 	
    static int 
    check_nh_ipv4(FILE *fp, in_addr *p_v4, int tag1, int tag2, int tag 3, int ret)  
    {
	if (ret == CONFD_ERR) {
	    fprintf (fp,"failure %d nexthop base, ipv4 address" [tag1=%d] [tag2=%d] [tag3=%d]\n",
			ret, tag1, tag2,tag3);
   	    return (ret);
	}  else {
	   / * limit string size for ipv4 address to 20 characters */
 	  p_str = inet_ntop (AFI_INET, p_ipv4, &buf,20);      
          if (p_str == NULL) {
	    fprintf (fp,"failure nexthop print, ipv4 address" [tag1=%d] [tag2=%d] [tag3=%d]\n",
			ret, tag1, tag2,tag3);
	    ret = CONF_ERR; 
	   } else {
   	    fprintf (fp,"nexthop base, ipv4 %s " [tag1=%d] [tag2=%d] [tag3=%d]\n",p_str, tag1, tag2);
          }
	}
	return (ret); 
    } 


    /* get ipv6-address from data base */
	
    static in_addr  
    get_nh_ipv6(int rsock, FILE *fp, in6_addr *p_v6, int tag, int tag2) 
    { 
	int ret;
	int tag3 = 0;
        string *p_str; 
        char buf[80];  
 
 	ret  = cdb_get_ipv6(rsock, p_v6, "ipv4-address");
        return(check_nh_ipv6 (fp, p_v6, tag, tag2, tag3, ret)); 
    }
   
    /* get src-ipv6-address from data base */
	
    static in_addr  
    get_nh_src_ipv6(int rsock, FILE *fp, in6_addr *p_v6, int tag, int tag2, int tag3) 
    { 
	int ret;
        string *p_str; 
        char buf[80];  
 
 	ret  = cdb_get_ipv6(rsock, p_v6, "src-ipv4-address");
        return(check_nh_ipv6 (fp, p_v6, tag, tag2, ret)); 
    }

    /* get dest-ipv6-address from data base */
	
    static in_addr  
    get_nh_dest_ipv6(int rsock, FILE *fp, in6_addr *p_v6, int tag, int tag2, int tag3) 
    { 
	int ret;
        string *p_str; 
        char buf[80];  
 
 	ret  = cdb_get_ipv6(rsock, p_v6, "dest-ipv4-address");
        return(check_nh_ipv6 (fp, p_v6, tag, tag2, ret)); 
    }
   /* check */ 
 
    static int 
    check_nh_ipv6(FILE *fp, in_addr *p_v6, int tag1, int tag2, int tag3,  int ret)  
    {
	if (ret == CONFD_ERR) {
	   fprintf (fp,"failure %d nexthop base, ipv4 address [tag1 = %d] [tag2 = %d][tag3 = %d]",\ 
		ret, tag1, tag2, tag3);
   	    return (ret);
	}  else {
	   / * limit string size for ipv4 address to 20 characters */
 	  p_str = inet6_ntop (AFI_INET6, p_ipv6, &buf,80);      
          if (p_str == NULL) {
	   fprintf (fp,"failure %d nexthop base, ipv4 address [tag1 = %d] [tag2 = %d][tag3 = %d]",\ 
		ret, tag1, tag2, tag3);
	   ret = CONF_ERR; 
	   } else {
   	    fprintf (fp,"nexthop base, ipv6 %s " [tag=%d] [tag=%d] [tag=%3]",p_str, tag1, tag2,tag3);
          }
        }
	return (ret); 
    }


    /* get

    static int 
    get_nh_mac(int rsock, FILE *fp, uint32_t *p_mac, int tag, int tag2) 
    { 
	int ret;
        string *p_str; 
        char buf[80];  
 
 	ret  = cdb_get_int32(rsock, p_mac, "ieee-mac-address");
        return (check_mac_address(fp, p_mac, tag1, tag2);
    }
    
    static int 
    check_nh_mac (FILE *fp, uint32_t p_mac, int tag, int tag2, int ret) 
    {
	if (ret == CONFD_ERR) {
	    printf (fp,"failure %d nexthop base, mac address" [tag=%d] [tag=%d]",ret, tag1, tag2);
   	    return (ret);
	}  else {
   	   fprintf (fp,"nexthop base, mac %d " [tag=%d] [tag=%d]",*p_mac, tag1, tag2);
        }
	return (ret); 
    }

    static_int 
    get_nh_tunnel_encap(int rsock, FILE *fp, i2rs_instance_t *p_ii, int tag1, int tag2, int tag3)   
    {
	int ret, ret1, ret2, ret3, ret4, ret5, ret6;
        int idx1, idx2;
        int tuntype;
        in_addr src_v4;
	in_addr dest_v4;
	in6_addr src_v6;
	in6_addr dest_v6;
	uint_8 proto_v4;
	uint_8 ttl;
	uint_8 dscp;
        i2rs_iftable_t *p_iif;  
       
	/* switch on tag 3 to ipv4, ipv6, mpls, gre, nvgre, vxlan  */
        idx1 = idx2 = 0;
	switch (tag3) {
	   case ipv4:
	     tuntype = I_tunnel_ipv4;
	     ret1 =  get_nh_src_ipv4(rsock,fp, &src_v4, tag1, tag2, tag3);
	     ret2 = get_nh_dest_ipv4(rsock,fp, &dest_v4, tag1, tag2, tag3);
	     ret3 = get_nh_protocol_v4(rsock,fp, &proto_v4, tag1, tag2, tag3);
	     ret4 = get_nh_ttl_v4(rsock,fp, &ttl, tag1, tag2, tag3);
	     ret5 = get_nh_dscp_v4(rsock,fp, &dscp, tag1, tag2, tag3);

             /* if parts are ok - create and insert 
              * table tunnel encap  entry (i2rs_tunnel_encap_t )
              */ 	
	     if ((ret1 == CONFD_OK) && (ret2 == CONFD_OK) && (ret3 == CONFD_OK)
                  && (ret4 == CONFD_OK) && (ret5==CONFD_OK)) {
		ret6 = insert_te_hdr_v4(fp, p_ii, src_v4, dest_v4, ttl, proto_v4, dscp, &idx1);
		if (ret6 == CONF_OK) {
	            ret = insert_te_tab_entry(fp, pii, idx1);     
	        }	
	     } else {     
	        ret = CONF_ERR; 
	     }
	     break;

	   case ipv6:
	     tuntype = I_tunnel_ipv6;
	     ret = CONF_ERR; 
	     break;
	
	   case mpls:
	     tuntype = I_tunnel_mpls;
	     ret = CONF_ERR; 
	     break;
	
	   case gre:
	     tuntype = I_tunnel_gre;
	     ret = CONF_ERR; 
	     break;
	  
	   case vxlan:
	     tuntype = I_tunnel_gre;
	     ret = CONF_ERR; 
	     break; 

	   case nvgre:
	     tuntype = I_tunnel_nvgre;
	     ret = CONF_ERR; 
	     break; 
	 }	
	     	
    }
  
    static_int 
    get_nh_tunnel_decap(int rsock, FILE *fp, i2rs_instance_t *p_ii, int tag1, int tag2, int tag3)   
    {
	int ret, ret1, ret2, ret3, ret4, ret5, ret6;
        int idx1, idx2;
        int tuntype;
	tuntype = I_NHB_SUBTYPE_TUN_DECAP;

	/* no support yet */
	return (CONF_ERR);	
    }
    static_int 
    get_nh_log_tunnel(int rsock, FILE *fp, i2rs_instance_t *p_ii, int tag1, int tag2, int tag3)   
    {
	int ret, ret1, ret2, ret3, ret4, ret5, ret6;
        int idx1, idx2;
        int tuntype;
	tuntype = I_NHB_SUBTYPE_LOG_TUN;

	/* no support yet */
	return (CONF_ERR);	
    }
    
   static_int 
    get_nh_rib(int rsock, FILE *fp, i2rs_instance_t *p_ii, int tag1, int tag2, int tag3)   
    {
	int ret, ret1, ret2, ret3, ret4, ret5, ret6;
        int idx1, idx2;
        int tuntype;
	tuntype = I_NHB_SUBTYPE_RIB ;

	 ntype = I_tunnel_rib;
        /* skh-- no support yet --implment soon */
	/* structure *char_name pointer to rib */  
	return (CONF_ERR);	
    }
   static_int 
    get_nh_nhid(int rsock, FILE *fp, i2rs_instance_t *p_ii, int tag1, int tag2, int tag3)   
    {
	int ret, ret1, ret2, ret3, ret4, ret5, ret6;
        int idx1, idx2;
        int tuntype;
	struct confd_idntityref nh_id;
	 
         tuntype = I_NHB_SUBTYPE_NH_ID ;
	 cdb_get_identityref(rsock, &nh_id,"nexthop-ref");    
	 find_nh_id(xx);
 
	return (CONF_ERR);	
    }
 
 
   static_int 
   get_nhbase(int rsock, FILE *fp, i2rs_nexthop_t *p_nh, i2rs_instance_t *p_ii, int tag1,  in tag2, int tag3) 
   { 
    int ret, ret2; 	
    uint32_t tmp;
    in_addr  v4;
    in_addr  *p_v4 = &v4; 
    in6_addr v6;
    in6_addr *p_v6 = &v6;   
    struct confd_identityref ifref;
    struct confd_identityref *p_if_ref;
    int idx = 0;

    	
    struct in_addr ipv4-addr;
    struct in_addr *p_v4 = &ipv4-addr;
    struct in6_addr ipv6-addr;
    struct in6_addr *p_v6 = &ipv6-addr;
    uint32_t mac;
    char buf[80];
    int len; 
    char *p_str;
    

       	switch (tag2)  {
	  case special-nexthop :
	     nh_subtype = I_NHB_SUBTYPE_SPECIAL;
             ret  = cdb_get_enum_value(rsock, &tmp, "special-nexthop");
	     if (ret == CONFD_ERR) {
		printf (fp,"failure %d nexthop base, special nexthop" [tag1=%d] [tag2=%d]",ret, tag1, tag2);
      	     } else {  
   	    	fprintf (fp,"nexthop base, special nexthop" [tag1=%d] [tag2=%d]",tag1, tag2) ;
            	p_nh->nh.nh_base.special_nh = (uint8_t) tmp; 
	     }	
	    break;

          case egress-interface-nexthop :
	     nh_subtype = I_NHB_SUBTYPE_EGRESSIF;
	     ret = get_eif(rsock, fp, &ifref, p_ii, &idx, tag1, tag2);     
	     if (ret = CONFD_OK) {
	        p_nh->nh.nh_base.nhb.elf_idx = idx;
	     }  else {
	       free_i2rs_ifs(pii, idx);  
	    }
  
             break;         
	
          case ipv4-address-nexthop :
	     nh_subtype = I_NHB_SUBTYPE_IPv4;
 	     ret = get_nh_ipv4(rsock, fp, &ipv4, tag1, tag2)     
   	     if (ret == CONFD_OK) {
        	p_nh->nh.nh_base.nhb.ipv4 = ipv4; 
             }	
	     break;
 
          case ipv6-address-nexthop :
	     nh_subtype = I_NHB_SUBTYPE_IPv6;
             ret = get_nh_ipv6(rsock, fp, p_ipv6, tag1, tag2); 
	     if (ret == CONFD_OK) { 
	          ret2 = cpyin6toin6(p_ipv6, &p_nh->nh.nh_base.nhb.ipv6);
  		  if (ret2 == CONFD_ERR) {
			ret = CONFD_ERR;
		  }			
	      }  
	      break;
                
	  case egress-interface-ipv4-nexthop :
	     nh_subtype = I_NHB_SUBTYPE_EIF_IPV4;
	     ret = get_eif(rsock, fp, &if-ref, p_ii, tag1, tag2);    
	     if (ret == CONFD_OK) {  
		 ret = get_nh_ipv4(rsock, fp, p_ipv4, tag1, tag2)     
		 if (ret == CONFD_OK) {
        	     p_nh->nh.nh_base.nhb.ife_ipv4.eif_idx =idx 
        	     p_nh->nh.nh_base.nhb.ife_ipv4.ipv4 = ipv4; 
		   }
	     }	 
	     break;

	   case egress-interface-ipv6-nexthop :  
	      nh_subtype = I_NHB_SUBTYPE_EIF_IPV6;
	      ret = get_eif(rsock, fp, &if-ref, pii, tag, tag2);     
	      if (ret == CONFD_OK) {
                p_nh->nh.nh_base.nhb.ife_ipv4.eif_idx =idx;
	        ret = get_nh_ipv6(rsock, fp, p_ipv6, tag, tag2)     
	        if (ret == CONFD_OK) {   
                    if (cpyin6toin6(p_ipv6, &p_nh->nh.nh_base.nhb.ife_ipv6) == 0) {
		      ret = CONFD_ERR; 
		    }  
		 } /* ret
	       } /* if get_eif */ 

		 break;
		 
           case egress-interface-mac-nexthop :  
	      nh_subtype = I_NHB_SUBTYPE_EIF_MAC;
	      ret = get_eif(rsock, fp, &if_ref, pii, tag, tag2);
	      if (ret == CONFD_OK) {
                 p_nh->nh.nh_base.nhb.ife_ipv4.eif_idx =idx;
		 ret = get_mac_nh(rsock, fp, &mac, tag, tag2); 

	      } 
	      break;

	   case tunnel-encap-nexthop:  
	      nh_subtype = I_NHB_SUBTYPE_TUN_ENCAP;
              ret = get_nh_tunnel_encap(rsock, fp, p_nh, p_ii, tag1, tag2, tag3); 
	      break;
		
	   case tunnel-decap-nexthop:
	      nh_subtype = I_NHB_SUBTYPE_TUN_DECAP;
	      ret = get_nh_tunnel_decap(rsock, fp, p_i, tag1, tag2, tag3);
	      break; 
		
	   case logical-tunnel-nexthop:
	      nh_subtype = I_NHB_SUBTYPE;
	      ret = get_nh_log_tunnel(rsock, fp, p_ii, tag1, tag2, tag3);
	      break;
			
	   case rib-name-nexthop:
	       nh_subtype = I_NHB_SUBTYPE_RIB;
	       ret = get_nh_rib(rsock, fp, p_vrf, tag1, tag2);
	       break;

	   case nexthop-identifire: 
	      nh_subtype = I_NHB_SUBTYPE_NH_ID;
	      ret = get_nh_nh(rsock, fp, p_vrf, tag1, tag2);
	      break; 
	 }
	if (ret == CONFD_OK) { 		
            p_nh->nexthop_type = nh_type;
            p_nh->nexthop_subtype = nh_subtype;
	} 
          
	return(ret);
   }

/*************** modify original nh_route ********************/   
 

  /* changing this a nexthop in this
   *  requires:  rtc (route change structure )   
   *             nhc (next change structure )  
   *
   *  rtc will exist for this route 
   *      1) if prefix was changed in procssinga
   *         before the nexthop 
   *      2) second+ route exists with same route-index 
   *         exist with the same route-index
   *         (add two routes twice) 
   *  
   * result: if rtc exists    
   *
   * change nh -directly            
   *  nhc 1) will 2nd second route in route list  
   *         exist with the same route-index
   *         (add two routes twice)  
   *          with different next hops).
   *          [ECMP - should come from replication]
   *    
   *      2) update route options - uses
   *         a) matches:prefix, attributes, vattributes
   *                    or nexthop (in order)
   *         b) sets nexthop
   *         c) sets attributes 
   *         d) sets vendor attributes
   *
   * both create 1) rtc - route change 
   *             2) htc - nexthop
   *  
   * nexthop are complicated by sharing 
   *  1) rib keeps 
   *      a) list of nexthops shared by routes nh_s[index] 
   *           + count (nhs_cnt), 
   *      b) list of nexthop not shared by rts nh_ns[index] 
   *          + count (nhns_cnt) 
   *   2) nexthop - flags sharing with rt    
   *          
   *  multi-headed write    
   *  design uses session id (SID) (sid_t)
   *   session id = transport connection (tid) + action (aid) + owner (owid)
   *        aid = sequence  + act (write, read, rpc, notify + sub-act) 
   *        owid =  customer id + priority id + opaque data 
   *    Not Implemented,  but will be needed for resolution of 
   *       
   */

   static   
   need_htc_rtc(FILE *fp, p_rib_t *p, i2rs_route_t *p_rt, i2rs_nexthop_t *p_nh,int rtnh_idx, ribnhs_idx,int rib_nhns_idx)
   { 
	
	/* is  nexthop is used on earlier route-id? 
  
	 if ((rt_nh_idx) && (p_rt->rtc_cnt == 0)  {
	   /* next hop is first overlap rtc */ 	
	   p_rtc = i2rs_create_rtc(p_rib, p_rt);
	   p_rtc->chg flags = I2RS_RTC_NHLIST;  
	   p_rtc->sid->nhc_sid = p_rt->rt_sid;
	   p_rtc->sid->nh_sid = p_rt->rt_nh[rt_nh_idx]->nh_sid; 
        }
	/* logic is not complete here */

     /* returns  0 for no rtc   
      * returns  1 for rtc only 
      * return   2 for rtc, htc
      * returning rtc only at this time
      */   
     return (1)       
 
   }  

/*********************main next-hop route *********/

/* get the next hop structure 
 * u_int32_t 	nexhhop id  	
 * boolean 	sharing-flag
 * enum/uint16  nexthop-type
 * struct 	nexthop-base 
 * struct 	nexthop-chain
 * 
 * struct nexthop-base
 *   
 */      
  static int get_i2rs_nh(int rsock, FILE *fp, i2rs_route_t *p_rt, i2rs_rib_t *p_rib, int rt_rtc_idx)
  {
   int ret = 0;
   uint32_t nh_index = 0;
   uint8_t  nh_share = 0; 

   int tag1, tag2, tag3;
   confd_keypath_t *kp; 
   struct confd_identityref if-ref;
   
 
   uint8_t  nh_share = 0; 
   uint16_t nh_type = 0; 
   uint16_t nh_subtype = 0; 
   
   int idx =  0;
   uint32_t rt_nh_idx = 0;
   uint32_t rib_nhs_idx = 0;
   uint32_t rib_nhns_idx = 0;
   i2rs_nexthop_t *p_nh;    
   
   i2rs_if_t *p_i2rs_if;
   
	/* parse nexthop index, sharing, and pathway
         * then grap nexthop by type 
	 * after valid 
	 * insert in rt_list, rtc, and rib shared/nonshared nh list   
         */
  
	/* get nexthop index */
        ret  = cdb_get_u_int32(rsock,&nh_index, "route/nexthop/route-id");
	if (ret == CONFD_ERR) {
   	    fprintf (fp,"failure in getting nexthop index [ret=%d]",ret) ;
	    return (ret);
	} else { 
        	fprintf (fp,"nexthop index %d [%d]",nt_index) ;
	}
	
        /* get sharing flag (sharable or not) */

        ret  = cdb_get_boolean(rsock,&nh_share, "route/nexthop/sharing_flag");
	if (ret == CONFD_ERR) {
   	    printf (fp,"failure in getting nexthop sharing flag [ret=%d]",ret) ;
	    return (ret);
	}	
	int *ret; 
        ret = cdb_getcwd_kpath(rsock,kp); 
        if (ret == CONFD_ERR) {
           fprintf (fp, "error %d in getting key path ptr\n",ok, kp);
           return (0);
	 }
       	
	tag1 = GET_NEXT_TAG;    	

	/* find nexthop by nexthop_id 
	 * search for it in rt_list, 
         * rib nh shared, non-shared tables, 
         */ 
	
	/* table index start at 1 table[0] is not used;  
         * (hack alert) 
         */

 	  rt_nh_idx = find_i2rs_nh(p_rib, p_rt, nh_index, nh_share, &rib_nhs_idx, &rib_nhns_idx ); 
   
	/* create temporary nh structure to put config nh   */
	p_nh = i2rs_create_nh(nh_index); 

	/* get next hop */

	switch (tag) {
	  case nexthop-base: 
	    nh_type = NHT_NEXTHOP_BASE; 
	    tag2 = GET_NEXT_TAG;
	    tag3 = -1;
            switch (tag2):  {
	      case tunnel-encap-nexthop:  
	      case tunnel-decap-nexthop:
	        tag3 = GET_NEXT_TAG;
		 break;
	    }
            ret = get_nhbase(rsock,fp,*p_nh, *p_ii, tag1, tag2, tag3); 
	    break;
 
	  case nexthop-chain:
	    nh_type = NHT_NEXTHOP_CHAIN;	
	    ret = CONFD_ERR;   /* not supported yet */
	    break;  
	  case nexthop-replicates:
	    nh_type = NHT_NEXTHOP_CHAIN;	
	    ret = CONFD_ERR;   /* not supported yet */
	    break;  
	  case nexthop-protection:
	    nh_type = NHT_NEXTHOP_CHAIN;	
	    ret = CONFD_ERR;   /* not supported yet */
	    break;  
	  case nexthop-load-balance:
	    nh_type = NHT_NEXTHOP_CHAIN;	
	    ret = CONFD_ERR;   /* not supported yet */
	    break;  
        } 	

	/* now add rtc and htc */ 
        need_htc_rtc(fp, p_rib, p_rt, rt_nh_idx, rib_nhs_idx, rib_nhns_idx);    

	fprintf(fp,"NH %n process done nh_type = %d, ret= %d", nh_type, ret);
	fprintf(fp,"tag1 [%d], tag2 [%d], tag3 [%d]", tag1, tag2, tag3);    

	 
   return (ret);  
   }

   

   /****************** end of next hop routines ******************/

  /*******************get prefix *********************************/

   static int
   cmp_rt_prefix(i2rs_route_t p_rt, i2rs_route_t *p_nrt)
   {
	 /* not implemented  
          *  return 1 different 
          *  return 2 same  
	  */ 
	  return (0); 
    }

  /* route routines */

   static int 
   get_rt_prefix(int rsock, FILE *fp, i2rs_route_t *p_rt) 
   { 
   zebra_vrf *p_vrf;
   i2rs_route_t *p_nrt; 
   confd_keypath_t *kp; 

   struct in_addr ip;
   int i, j, m, ret, max_rts;
   int tag, tag2, idx;
   uint64_t rt-index = 0;
   uint16_t route-type;
   struct in_addr src_ipv4;
   struct in_addr dst_ipv4;
   struct in6_addr src_ipv6;
   struct in6_addr dst_ipv6;
   uint32_t rt-tmp; 
   enum if-tmp;
   size_t size;
   struct confd_ipv4_prefix cd_ipv4;
   struct confd_ipv6_prefix cd_ipv6; 
       
      /* 2. get route prefix (route type, match-type, prefix)  */
         
      ret = cdb_getcwd_kpath(rsock,kp); 
      if (ret == CONFD_ERR) {
         fprintf (fp, "error %d in getting key path ptr\n",ok,kp );
          return (ret);
       }
          
       tag = GET_NEXT_TAG;
       if (tag != match) {
         fprintf (fp, "tag %d should be match\n",tag, match);
           return (CONFD_ERR);
       }
       tag = GET_NEXT_TAG;
       fprintf (fp, "route-type %d", tag);
 
       switch (tag) {
          case ipv4:
	    type = I_rt_ipv4;  
            tag2 = GET_NEXT_TAG;
	    fprintf (fp, "route-type %d, sub-type%d\n", tag, tag2)  
            p_rt->rt_prefix.rt_type = type;
            p_rt->rt_prefix.rt_subtype = sub-type;

	    /* get ip-route-match-type */
            switch (tag2) {  
	    case dest-ipv4-address: 
              ret = cdb_get_ipv4prefix(rsock,dst_ipv4,"dest-ipv4-prefix"); 
	      if (ret == CONF_OK) {
	         p_rt->rt_prefix.pfx_match.m.dest_ipv4.afi = AFI_IP;
		 p_rt->rt_prefix.pfx_match.m.dest_ipv4.len = ipv4.len; 
		 p_rt->rt_prefix.pfx_match.m.dest_ipv4.pfx4 = ipv4.ip;
	       }	 
	      break;
	       
	     case src-ipv4-address: 
               ret = cdb_get_ipv4prefix(rsock,src_ipv4,"src-ipv4-prefix"); 
	       if (ret == CONFD_OK) {
		  p_rt->rt_prefix.pfx_match.m.src_ipv4.afi = AFI_IP;
		  p_rt->rt_prefix.pfx_match.m.src_ipv4.len = ipv4.len; 
		  p_rt->rt_prefix.pfx_match.m.src_ipv4.pfx4 = ipv4.ip; 
		 }
		 break;
	       
		case dest-src-ipv4-address:
                 ret = cdb_get_ipv4prefix(rsock,dst_ipv4,"dest-ipv4-address"); 
		 if (ret == CONFD_OK) {
		  p_rt->rt_prefix.pfx_match.m.sdst_ipv4.dest_ipv4.afi = AFI_IP;
		  p_rt->rt_prefix.pfx_match.m.dest_ipv4.dest_ipv4.len = ipv4.len; 
		  p_rt->rt_prefix.pfx_match.m.dest_ipv4.dest_ipv4.pfx4 = ipv4.ip; 
		  ret 2 = cdb_get_ipv4prefix(rsock,src_ipv4,"src-ipv4-prefix"); 
		  if (ret2 == CONFD_OK) {
		    p_rt->rt_prefix.pfx_match.m.sdst_ipv4.src_ipv4.afi = AFI_IP;
		    p_rt->rt_prefix.pfx_match.m.dest_ipv4.src_ipv4.len = ipv4.len; 
		    p_rt->rt_prefix.pfx_match.m.dest_ipv4.src_ipv4.pfx4 = ipv4.ip; 
		    } else {
	             ret = CONFD_ERR; 
                    }
		}
		default: 
		 ret=CONFD_ERR;		
	     }
	     break;

  	  
          case ipv6:
	    type = I_rt_ipv6;  
            tag2 = GET_NEXT_TAG;
	    fprintf (fp, "route-type %d, sub-type%d\n", tag, tag2)  
            p_rt->rt_prefix.rt_type = type;
            p_rt->rt_prefix.rt_subtype = sub-type;

	    /* get ip-route-match-type */
             switch (tag2) {  
		 case dest-ipv6-address: 
                 ret = cdb_get_ipv6prefix(rsock,dst_ipv4,"dest-ipv6-prefix"); 
	         if (ret == CONFD_OK) {
		    p_rt->rt_prefix.pfx_match.m.dest_ipv6.afi = AFI_IP6;
		    p_rt->rt_prefix.pfx_match.m.dest_ipv6.len = ipv6.len; 
		    p_rt->rt_prefix.pfx_match.m.dest_ipv6.pfx6 = ipv6.ip;
		  }	 
		  break;
	       
		case src-ipv6-address: 
                 ret = cdb_get_ipv6prefix(rsock,src_ipv4,"src-ipv6-prefix"); 
	         if (ret == CONFD_OK) {
		  p_rt->rt_prefix.pfx_match.m.src_ipv6.afi = AFI_IP6;
		  p_rt->rt_prefix.pfx_match.m.src_ipv6.len = ipv4.len; 
		  p_rt->rt_prefix.pfx_match.m.src_ipv6.pfx6 = ipv4.ip; 
		 }
		 break;
	       
		case dest-src-ipv6-address:
                 ret = cdb_get_ipv6prefix(rsock,dst_ipv4,"dest-ipv6-address"); 
		 if (ret == CONFD_OK) {
		    p_rt->rt_prefix.pfx_match.m.sdst_ipv6.dest_ipv6.afi = AFI_IP6;
		    p_rt->rt_prefix.pfx_match.m.sdst_ipv6.dest_ipv6.len = ipv6.len; 
		    p_rt->rt_prefix.pfx_match.m.sdst_ipv6.dest_ipv6.pfx6 = ipv6.ip;
		    ret2 = cdb_get_ipv6prefix(rsock,src_ipv4,"src-ipv4-prefix"); 
		    if (ret2 == CONFD_OK) {
		      p_rt->rt_prefix.pfx_match.m.sdst_ipv6.src_ipv6.afi = AFI_IP6;
		      p_rt->rt_prefix.pfx_match.m.sdst_ipv6.src_ipv6.len = ipv6.len; 
		      p_rt->rt_prefix.pfx_match.m.sdst_ipv6.src_ipv6.pfx6 = ipv6.ip;
		    } else {
		      ret = CONFD_ERR;
	            }
		 } 

		default: 
		 ret=CONFD_ERR;	
	      }
	     break;	

	    case mpls-route:
             type = I_rt_mpls;
	     ret = cdb_get_u_int32(rsock,&rt_tmp,"mpls-label");
	     if (ret == CONF_OK) {
	      	fprintf (fp, "route-type %d [tag: %d],type,  tag)  
              	p_rt->rt_prefix.rt_type = type;
              	p_rt->rt_prefix.rt_subtype = I_match_mpls_subtype;
              	p_rt->rt_prefix.pfx_match.m.mpls_label = rt_tmp 
	      }
	     break;

	    case mac-route:
	     type = I_rt_ieee_mac; 
	     ret = cdb_get_u_int32(rsock,&rt-tmp,"mac-route");
	     if (ret == CONF_OK) {
	     	fprintf (fp, "route-type %d [tag: %d], type, tag)  
              	p_rt->rt_prefix.rt_type = type;
              	p_rt->rt_prefix.rt_subtype = I_match_mac_subtype;
              	p_rt->rt_prefix.pfx_match.m.mpls_lable = rt_tmp; 
	       }
	     break;	

	    case interface-route: 
	     ret = cdb_get_eum(rsock,&if-tmp,"mac-route");
             if (ret == CONF_OK) {
              	p_rt->rt_prefix.rt_type = type;
              	p_rt->rt_prefix.rt_subtype = I_match_mac_subtype;
              	p_rt->rt_prefix.pfx_match.m.ifindex = rt_tmp;
		/* add find for ifindex */
                p_rt->rt_prefix.pfx_match.m.ifindex[0] = " ";
                p_rt->rt_prefix.pfx_match.m.ifindex[1] = NULL;
 	      }
	     break; 

	    case default
	     ret = CONFD_ERR; 
	  }
	return (ret);
   }

   /*****************route status *******************************/
 
   /* code  not in place - just skipping in file */ 
   static int 
   get_rt_status(int rsock, FILE *fp, i2rs_route_t *p_rt) {
	return (CONFD_OK);
   }  
  
  /*********************route attributes ************************/

   /* code  not in place - just skipping in file */ 
   static int 
   get_rt_attr(int rsock, FILE *fp, i2rs_route_t *p_rt) {
	return (CONFD_OK);
   }  

  /***********************vendor attributes*********************/
   /* code  not in place - just skipping in file */ 
   static int 
   get_rt_vattr(int rsock, FILE *fp, i2rs_route_t *p_rt) {
	return (CONFD_OK);
   }

  /***********************route list **************************/ 

  /*  get_i2rs_rt_list is the main loop
   * 
   *  loops reading existing config route in route-list rib 
   *   [route = (prefix, nh, status, attributes, vendor attributes]  
   *    
   *   i2rs_rib.rtl - route list    
   *   i2rs_rib.nh_s - next hop - shared between routes
   *   i2rs_rib.nh_ns - to keep track of these
   *   i2rs_rib.rtc_cnt  - right now only rib count, with 
   *                     data kept routes (must walk loop) 
   *             
   *   i2rs_rib.nhc_cnt - right now only rib count with 
   *                      data kept in nhc associate with 
   *                      nexthop structure
   *
   *  sid -  will reference table to map 64bit to composite 
   *   
   *  
   *  post handling reading of rt_list - will 
   *    1)  handle merging of changes into current i2rs_state
   *    2)  making change to gate route table 
   *      
   *  
   *  rtc_cnt + nhc_cnt - should decrement during processing                         
   */
   
   static int 
   get_i2rs_rt_list(int rsock, FILE *fp,i2rs_rib_t *p_rib, uint16_t afi, uint8_t safi, int ribmod)
  {
   zebra_vrf *p_vrf;
   i2rs_route_t *p_rt; 

   struct in_addr ip;
   int i, j, m, ret, max_rts;
   int tag, tag2, idx, mod;
   uint64_t rt-index = 0;
   uint16_t route-type;
   struct in_addr src_ipv4;
   struct in_addr dst_ipv4;
   struct in6_addr src_ipv6;
   struct in6_addr dst_ipv6;
   uint32_t rt-tmp; 
   enum if-tmp;
   size_t size;
   struct confd_ipv4_prefix cd_ipv4;
   struct confd_ipv6_prefix cd_ipv6; 
   confd_hkepath_t *kp; 
	

      /* set-up for parsing route -list  */
      p_vrf = p_rib->p_zvrf;

      m = cdb_num_instances(rsock,"/ietf-i2rs-rib/routing-instance/rib-list[n]/route-list");
       if (m < 1 ) { 
           fprintf (fp, "m =  %d routes\n", m );  
	   return (0); 
       }

       /* limit routes to what will fit in the route table */ 
       if (m > I2RS_RIB_RT_MAX) {
       	   max_rts = I2RS_RT_MAX - (p_rib->rt_cnt+1);  
           fprintf (fp, "route-list [%d] > I2RS_RIB_RT_MAX (%d) ", m, max_rts );
       } else {
	   if (m > max_rts) {	
            fprintf (fp, "route-list [%d] > space left in rt_list (%d), will ignore rest ", m, max_rts );
	    } else {
	       max_rts = m; 
           }	
       }
        	
       /* loop to get route-list entries:   
        *  route-prefix, nexthop, route-status, 
        *  route-attribute, route-vendor-attributes 
        */  
  
       for (i=0; i < max_rts; i++) {
	
	/* 1. get route index for first route-prefix 
         * route-prefix = route-index, match (ipv4, ipv6, mpls, mac)         
         */ 
  
        ret  = cdb_get_u_int64(rsock,&rt_index, "route/route-prefix/route-index");
	if (ret != CONFD_OK) {
           fprintf (fp, "error %d in getting rt[%d] route-index\n",ret, i)
           return (1);
        }
	   
	 idx = find_rt(p_rib,&rt_index); 
	 if (idx == -1)   {
            /* new route  */ 
             fprintf (fp,"new route-index =%d/n",route-index );
	     p_rt = create_rt(p_rib, rt_index);
	     p_rtc = (i2rs_rtc_t) NULL;
	     p_nrt = p_rt; 		
	  }
	 else {
	     /* existing route with the same id  
	      * must set-up the route change list    
              */ 
	      p_rt = p_rib->rt_list[idx];
	      p_rtc = i2rs_create_rtc(p_rt,p_rib->chg_id); 
	      p_nrt = &p_rtc->rt_rtc; 	
	      mod = 1; 
	  }          
	 
	  /* get prefix and nexthop */
           
	  ret = get_rt_prefix(rsock,fp, p_rib,p_nrt);
	  if (ret != CONFD_OK) {        
	     return (ret);
	  }
	  mod_rt = cmp_rt_prefix(p_rt, p_nrt);
          if ((mod_rt) || (p_rt->rtc_cnt == 0) {
	    fprintf(fp, "broken logic in code mod_rt with no rtc"\n)
	    return (CONFD_ERR);  
	  }  

	  ret = get_rt_nh(rsock, fp, p_rib, p_nrt); 
	  if (ret != CONFD_K) {        
	     return (ret);
	  } 

	 /* logic below is nulled out */ 
	  ret = get_rt_status(rsock,fp, p_rib, p_nrt);	
	  if (ret != CONFD_OK) {        
	     return (ret)
	  } 
	  
	  ret = get_rt_attributes(rsock,fp, p_rib,p_nrt);	
	  if (ret != CONFD_OK) {        
	     return (ret)
	  } 
	  
	  ret = get_vendor_attributes(rsock,fp, p_rib, p_nrt);	
	  if (ret != CONFD_OK) {        
	     return (ret)
	  } 

       } /* end of for loop */	     
        fprintf (fp, "for loop exit routes %d", m);
	return (m);
 }

 /****************** i2rs rib **************************************/

  static i2rs_rib_t 
  create_i2rs_rib(i2rs_instance_t *p_ii, afi_t afi, safi_t safi, char *p_n, int ip_rpf_check) 
  { 
    zebra_vrf  *p_vrf;
    i2rs_rib_t *p_rib;

        /* create rib and rib name space in gated */
	p_rib = XMALLOC(MEM_TYPE_I2RS_RIB, sizeof (i2rs_rib_t));	 

	/* create local space for rib name */	
	p_name = (u_char *) XMALLOC(MEM_TYPE_I2RS_RIB, I2RS_MAX_RIB_NAME);
	strncpy(p_name, p_n, I2RS_MAX_RIB_NAME);
	p_rib->p_name = p_name; 

        /* save ptr to name, afi, safi, ip_rpf_check	 */
        p_rib->afi = (uint16_t) afi;
        p_rib->safi = (uint8_t) safi;
        p_rib->ip_rpf_check = (uint8_t) ip_rpf_check;
	p_rib->rt_cnt = 0;
	p_rib->nh_cnt = 0;
        p_rib->chg_id = 0;

	/* link to VRF */	
	p_rib->vrf_id = p_ii->vrf_id; 	
	p_rib->p_vrf = p_ii->zvrf; 	
       
	p_vrf->i2rib[afi][safi] = p_rib;
	return (p_rib); 		
  }  

  extern int 
  find_i2rs_rib (FILE *fp,i2rs_instance_t *p_ii,afi_t afi, safi_t safi, char *p_name, int ip_rpf_check, int *ribmod)
  {
    i2rs_rib_t *p_rib; 
  
	p_vrf = p_ii->zvrf;
        p_rib = p_vrf->i2rs_rib[afi][safi]; 
	/* if there is no I2RS RIB for this afi/afi create one */
	if (p_rib != (i2rs_rib_t *) NULL) {
	    if (strncpy(p_rib->name,p_name,I2RS_MAX_RIB_NAME)) {
               /* not this name - so this is an error */
	 	fprintf(fp, "not rib name for [afi:%d],[safi:%d] installed rib: %s, confd rib: %s", \ 
                    afi, safi,p_rib->name, p_name); 
	        return(CONFD_ERR);	
	     } else {
	     /* rib is the same, and the configuration is 
              * changing the route list and nexthop list 
              */
	      *p_ribmod;  
	      *p_rib->chg_id++; 
	    }
	} else {
	/* no rib exists - create it and initial  */ 	
	 p_rib = create_i2rs_rib(p_ii, afi, safi, p_name, ip_rpf_chk);
	}
	return (CONFD_OK);  
  }

  /* get the rib list */
  /*  I2RS - RIB are identified  by name 
   *     for address-family (1 afi/safi pair) 
   *     with a set of interfaces 
   * 
   *  quagga has RIBs + interfaces per VRF 
   *   the instance is similar to a VRF
   *         
   *   are built on address-family i
   *  (afi/saf pair) 
   *
   *   


   static int 
   get_rib_list(int rsock, FILE *fp, i2rs_instance_t *p_ii)
   {
   i2rs_rib_t *p_irib; 
   struct in_addr ip;
   char *p_name;
   char *p_ribname;
   int i,  m, irib ;
   int ok = 0;
   int support = 0;
   uint32_t addrfam;
   uint16_t afi; 
   uint8_t safi;
   int ip_rpf_check = 0;
   uint32_t route-type;
   struct confd_ipv4_prefix ipv4-prefix;
   struct confd_ipv6_prefix ipv6-prefix; 
   char buf[YANG_BUFSIZ];

   /* get number of ribs  */

      if (cdb_num_instances(rsock,"/ietf-i2rs-rib/routing-instance/rib-list") == CONFD_ERR) {
    	fprintf(fp, "no ribs in list\n");
        return (CONFD_ERR);
      }
      fprintf(fp, "rib-list[%d]/n", n );

      /* parse the RIB info */
      for (i=0; i < n; i+) {
     	/* get the RIB name - print, create permanent storage */
     	if (cdb_get_str(rsock,p_name,I2RS_RIB_MAX_NAME),"name") == CONFD_ERR) {
       		fprintf(fp,"rib[%d] name get failed ret=%d", i, ok);
		return (CONFD_ERR);	
	 }
     	fprintf(fp,"rib[%d] name =  %s",i, p_name);
        if (cdb_get_enum_value(rsock,&addrfam,"address-family") == CONFD_ERR) {         
      		fprintf(fp,"rib[%d] failed to obtain name", i);
      	 	return (0);
	}
	fprintf(fp,"rib[%d] address-family = %d",i, &ribfam);

	/* check to see if address family is supported) */
   	if (addressfamily_to_afisafi(fp,&addfam,&afi,&safi) == 0) {
	   fprintf(fp,"rib[%d] address-family = %d\h", addrfam);
            return (0);
 	 }
        
        /* get the ip rpf check */
        ip_rpf_check = 0;
        if (cdb_get_boolean(rsock,&ip_rpf_check,"ip-rpf-check") != CONFD_OK) {
            return (0);
	}

	/* find rib or create one if it is not there */
	ribmod = 0;
	if (find_rib(p_ii,fp, name, afi, safi, ip_rpf_check, ribmod) == CONFD_OK) {
	   p_rib = p_ii->p_zvrf->i2rs_rib[afi][safi]; 

           if (get_i2rs_rt_list(rsock,fp,p_rib,afi, safi,ribmod) == CONFD_ERR) { 
	    	return (CONFD_ERR);
	   }
	    
        }
	  
      } /* end of for loop */

     return (CONFD_OK);
   }

 
  static int addressfamily_to_afisafi(FILE *fp, uint32_t af,uint16_t *p_afi, uint8_t *p_safi)  
  {
  int support = 0;

    switch (addrfam) {
     case I_match_rib_ipv4 :
	p_afi = (uint16_t) AFI_IPV4;
        p_safi = (uint8_t) SAFI_UNICAST;
	support=1;
        break; 
     
     case I_match_rib_ipv6:  		      
	p_afi = (uint16_t) AFI_IPV6;
        p_safi = (uint8_t) SAFI_UNICAST;
	support=1;
        break; 
 
     case I_match_rib_mpls : 
        p_afi = (uint16_t) AFI_MPLS
	p_safi = (uint8_t) SAFI_UNICAST;
        support= 2;
	break;

     case I_match_rib_IEEE_MAC: 
        p_afi = (uint16_t) AFI_MPLS
	p_safi = (uint8_t) SAFI_UNICAST;
        support= 2;
	break;
	
     default: 
       p_afi =  (uint16_t)  0; 
       p_safi = (uint8_t)  0; 
       break;
    }
   
	fprintf (fp, "afi = %d, safi = %d, support=%d (0-no, 1=yes, 2 future)",\ 
		 afi, safi, support);
	return (support)	
  }

 

  /***********  instance code  **********************************/
   /*  instance main route 
   *
   *  quagga has RIBs + interfaces per VRF 
   *   the instance is similar to a VRF
   *   i2rs_instance_t keeps what is read  + quagga vrf link 
   *    i2rs-rib read: instance name, router-id, cnt of 
   *                   interface, id/names of interfaces   
   *     instance<==> vrf 
   *
   *  VRF in Quagga has  (rib.h - for zebra subdirectory)
   *     in rib struct (rib_t) -> link to i2rs rib                   
   *     in vrf structure:  links to pointers to  
   *      1) i2rs_instance_t   i2rs_instance  
   *      2) i2rs_rib_t        i2rs_rib [afi][safi]
   *       table of ribs/vrf by afi/safi
   *  
   *      3) i2rs_if_table_t   i2rs_if_tab;
   *         table of interfaces - links to configured  
   *           i2rs tunnels and physical ifindex/name    
   *           i2rs_tun_encap_iftab_t - encap/decap methods 
   *           i2rs_tun_decap_iftab_t    link to  interface
   *   
   *           i2rs_tunnel_encap_t  -cfg encap/decap methods 
   *           i2rs_tunnel_decap_t     
   */         
   /*--------------------------------------------------*/
   
  static int 
  get_i2rs_instance(int rsock, FILE *fp, i2rs_instance_t *p_ins)
  {
   int i,n;
   int conf_ok = 0;
   char buf[I2RS_MAX_INSTANCE_NAME];

   /* get instance name */

   ok = cdb_get_str(rsock, &buf[0],I2RS_MAX_INSTANCE_NAME, \ 
       "/ietf-i2rs-rib/routing-instance/name");

   if (ok == CONF_OK) {     
   	fprintf(fp,"instance name %s\n",ip->name)
    }
    else {
   	fprintf(fp,"instance name get failed return %d\n", ok);
        return (ok);
    }
    /* get router-id */
       ok = cdb_get_ipv4(rsock,&p_ins->router_id,    
       "/ietf-i2rs-rib/routing-instance/router-id");
   
   if (ok == CONF_OK) {     
   	fprintf(fp,"router-id %s\n",inet_nto(p_ins->router-id)); 
    }
    else {
   	fprintf(fp,"instance router-id failed return %d \n",ok);
        return (ok);
    }


   /* get lookup-limit */
     cdb_get_uint8(rsock, &p_ins->lookup_limit,I2RS_MAX_INSTANCE_NAME, \ 
       "/ietf-i2rs-rib/routing-instance/router-id");

   if (ok == CONF_OK) {     
   	fprintf(fp,"lookup-limt = %d"\n, n); 
    }
    else {
   	fprintf(fp,"instance lookup-limit failed return %d \n",ok);
        return (ok);
    }

     /* get interface-list  */
    n = cdb_num_instances(rsock,"/ietf-i2rs-rib/interface-list"); 
     fprintf(fp,"interfaces = %d", n); 
     if (n > I2RS_MAX_IF)  {
     n = I2RS_MAX_IF;
     fprintf(fp,"greater than I2RS_MAX_IF set at max  = %d", n); 
    } 
   
   for (i=0, i < n, i++) 
     { 
      	ok = cdb_get_str(rsock, &p_ins->i2rs_if[i],I2RS_MAX_IF_NAME, \ 
       		"/ietf-i2rs-rib/routing-instance/name");
        if (ok == CONF_OK) {
 		fprintf(fp,"interface[%d] = %s\n",i,&p_ins->i2rs_if[i]);
	}	
	 else  {
 		fprintf(fp,"interface[%d] read failed return =%d \n",i,ok]);
		return (ok);
	}
     }

   return(0);
  }

  static int link_instance_to_vrf(FILE *fp, i2rs_instance_t *p_ii)    
  {
   zebra_vrf *p_vrf; 
   int i;

  	p_vrf = find_i2rs_instance(p_ii);
  	if (p_vrf == NULL) {
    	fprintf (fp, "i2rs instance cannot be found p_ii->name: %s\n, p_ii->name);
    	return (0);
   	}

  	p_vrf->i2rs_instance->router_id = p_ii->router_id;
  	p_vrf->i2rs_instance->lookup_limit = p_ii->lookup_limit  
  	p_vrf->i2rs_instance->if_cnt = p_ii->if_cnt;
  	for (i = 0, i < p_ii->if_cnt, i++) {
 	   p_vrf->i2rs_instance->if_name[i] = p_ii->if_name[i];		
  	}
  	return (1);     
  }

 
/*********** read the configuration ************8*/

static int read_conf(struct sockaddr_in *addr, int act_id, int fcn_id, int cus_id )
{
    FILE *fp;
    string instance; 
    i2rs_rib_t rib;
    i2rs_rib_t *p_rib=&rib; 
    struct i2rs_instance_info i2rs_instance;
    struct i2rs_instance_info *p_ins = &i2rs_instance; 
     
    struct nexthop nh-r;
    struct rt rt-r;  
    int i, n, tmp;
    int rsock;
    int i2rsd__ns;

    if ((rsock = socket(PF_INET, SOCK_STREAM, 0)) < 0 )
        confd_fatal("Failed to open socket\n");

    if (cdb_connect(rsock, CDB_READ_SOCKET, (struct sockaddr*)addr,
                      sizeof (struct sockaddr_in)) < 0) {
        return (CONFD_ERR);
    }

    if (cdb_start_session(rsock, CDB_RUNNING) != CONFD_OK) {
        return (CONFD_ERR);
     }
     
    cdb_set_namespace(rsock, i2rsd__ns);

    if ((fp = fopen("i2rsd.conf.tmp", "w")) == NULL) {
        cdb_close(rsock);
        return CONFD_ERR;
    }

    if (get_i2rs_instance(rsock,fp,&i2rs_instance)) {
        cdb_close(rsock);
        return (CONFD_ERR); 
     }

     /* got a valid instance, link to zebra vrf   */

    if (link_instance_to_vrf(fp, p_ins)) {
       /* rib needs error code - no instance of that   name */ 
       return (CONFD_ERR);    
     }  
   
     get_rib_list(rsock,fp, p_ins);
     fprintf(fp, "rib %s\n", rib.name);

         
     process_rib_list(fp, p_ins,&rt_status); 
  

    fclose(fp);
    return cdb_close(rsock);
  }
 /************************************************************/

  /***** processing rib list ********************************/
  /* process rib list to 
   * 1) reduce multiple changes within a sid 
   *    (in future set of sid)
   *    for route changes (rtc) or nh changes (nhc)   
   *   [first pass - use one client, ignore mh for confd]
   *     
   * 2) process route add/change/delete sid (or set)   
   *    recording status to route and 
   *    queueing updates  to confd        
   *    with all tables in zebra space
   *    task can be kicked off in zebra or 
   *    in i2rsd          
   * 
   * 3) shared space in vrf table allows 
   *    zebra routes to kick off  
   * 
   */ 

  extern int process_rib_list (FILE *fp, i2rs_instance_t *p_ii) 
  {
    return (1);
  }


 /**************************************************************/
 /* future main line code for i2rsd in gated                   */
 /* chnages: 
  *  1) change confd to ietf-system example to  
  *    get rpc, notification, read, write 
  *  2) change main to     
  */ 
   
int main(int argc, char **argv)
{
    struct sockaddr_in addr;
    int subsock;
    int status;
    int mpoint;
    int act_id, fcn_id, cus_id ;

    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr.sin_family = AF_INET;
    addr.sin_port = htons(CONFD_PORT);
    act_id = 0;
    fcn_id = 0; /* read initial */ 
    cus_id = 0;
    confd_init(argv[0], stderr, CONFD_TRACE);

    /*
     * Setup subscriptions
     */
    if ((subsock = socket(PF_INET, SOCK_STREAM, 0)) < 0 )
        confd_fatal("Failed to open socket\n");

    if (cdb_connect(subsock, CDB_SUBSCRIPTION_SOCKET, (struct sockaddr*)&addr,
                      sizeof (struct sockaddr_in)) < 0)
        confd_fatal("Failed to cdb_connect() to confd \n");

    if ((status = cdb_subscribe(subsock, 3, i2rsd__ns, &mpoint, "/ietf-i2rs-rib"))
        != CONFD_OK) {
        fprintf(stderr, "Terminate: subscribe %d\n", status);
        exit(0);
    }
    if (cdb_subscribe_done(subsock) != CONFD_OK) {
        confd_fatal("cdb_subscribe_done() failed");
         fprintf(stderr, "Subscription point = %d\n", mpoint);
    }
 
    /*
     * Read initial config
     */
    
    if ((status = read_conf(&addr,&act_id, &fcn_id &cus_id) != CONFD_OK) {
        fprintf(stderr, "Terminate: read_conf %d\n", status);
        exit(0);
    }
      /* update action
  
      rename("i2rs.conf.tmp", "i2rsd_conf.log");

    /* This is the place to HUP the daemon */
    /* integrate quagga with confd main loop */       

    while (1) {
        static int poll_fail_counter=0;
        struct pollfd set[1];

        set[0].fd = subsock;
        set[0].events = POLLIN;
        set[0].revents = 0;

        if (poll(&set[0], 1, -1) < 0) {
            perror("Poll failed:");
            if(++poll_fail_counter < 10)
                continue;
            fprintf(stderr, "Too many poll failures, terminating\n");
            exit(1);
        }

        poll_fail_counter = 0;
        if (set[0].revents & POLLIN) {
            int sub_points[1];
            int reslen;

            if ((status = cdb_read_subscription_socket(subsock,
                                                       &sub_points[0],
                                                       &reslen)) != CONFD_OK) {
                fprintf(stderr, "terminate sub_read: %d\n", status);
                exit(1);
            }
            if (reslen > 0) {
                if ((status = read_conf(&addr)) != CONFD_OK) {
                    fprintf(stderr, "Terminate: read_conf %d\n", status);
                    exit(1);
                }
            }
            fprintf(stderr, "Read new config, updating dhcpd config \n");
            rename("dhcpd.conf.tmp", "dhcpd.conf");
            /* this is the place to HUP the daemon */

            if ((status = cdb_sync_subscription_socket(subsock,
                                                       CDB_DONE_PRIORITY))
                != CONFD_OK) {
                fprintf(stderr, "failed to sync subscription: %d\n", status);
                exit(1);
            }
        }
    }
}

/********************************************************************/
