
/* define file for i2rsd to router */ 


#ifndef vrf_id_t  
typedef u_int16_t vrf_id_t;
#endif

/* here where we define memory process */
/* XMALLOC calls 
 * XMALLOC(memory-type,size)
 *  
 * FREE types 
 *  
 * MEMORY types  
 */

/* the following types are added in memtypes  enum
 * MTYPE_I2
 *  MTYPE_I2RS_INSTANCE,
 *  MTYPE_I2RS_IFTABLE,
 *  MTYPE_I2RS_RIB,
 *  MTYPE_I2RS_ROUTE,
 *  MTYPE_I2RS_NEXTHOP, 
 *  MTYPE_I2RS_RTC, 
 *  MTYPE_I2RS_HTC,  
 *  MTYPE_VTYSH_CONFIG,
 */
 
/* processing structure for rt-table 
 * additions  in quagga zebra route adds  
 *
 *  
 * ***skh move to specific router handling file 
 *
 *  rib.h - from zebra puts in vrf table   
 * 
 *   what  
 *   instance table   struct i2rs_instance *i2rs_instance;
 *   rib table        struct i2rs_rib  	   *i2rs_rib[AFI_MAX][SAFI_MAX];  
 *   if-table         struct i2rs_if_table *i2rs_if_tab;
 *
 *  if-table links i2rs interface config to system names  
 *  this structure links i2rsd_conf to the router handling 
 *  and processing      
 *   
 */
  
  struct i2rsd_rtr {
	uint16_t	i_vrf_id;	 /* zebra vrf id  */	         	
        char            *i_rt_vrf;	 /* points to router process */  
	int  	        rtr_zproc_status; /* zebra process  */ 
        int		rtr_p_status;     /*pending status */
  };



